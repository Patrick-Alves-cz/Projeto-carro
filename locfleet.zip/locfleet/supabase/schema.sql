-- ═══════════════════════════════════════════════════════════════════════
-- schema.sql — schema do LocFleet na nuvem (Supabase)
-- ═══════════════════════════════════════════════════════════════════════
--
-- Este arquivo é idempotente — pode ser rodado várias vezes sem dar erro.
-- Cada comando primeiro verifica/remove o que já existe antes de recriar.
--
-- NOTA DE ARQUITETURA — "tenant_id" vs "user_id":
-- Hoje o LocFleet usa um modelo de 1 login = 1 empresa. Por isso, o
-- user_id do Supabase Auth JÁ FUNCIONA como o identificador do tenant —
-- não criamos uma coluna "tenant_id" separada porque seria redundante
-- (seria sempre igual ao user_id). Se um dia você quiser que VÁRIOS
-- funcionários de uma mesma empresa façam login com contas próprias,
-- aí sim vale a pena separar "tenant" de "usuário" numa tabela própria
-- — mas isso é trabalho para quando o negócio realmente precisar disso.
-- ═══════════════════════════════════════════════════════════════════════

-- ── Tabela 1: kv_store — os dados de cada empresa ───────────────────────
create table if not exists kv_store (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  key text not null,
  value jsonb not null,
  updated_at timestamptz default now(),
  unique (user_id, key)
);

create index if not exists kv_store_user_id_idx on kv_store (user_id);

alter table kv_store enable row level security;

-- ── Tabela 2: profiles — 1 linha por empresa/cliente ─────────────────────
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  company_name text,
  active boolean not null default true,
  role text not null default 'customer' check (role in ('customer', 'admin')),
  plan text not null default 'trial',
  created_at timestamptz default now()
);

-- Caso a tabela já existisse de uma versão anterior (antes do campo "role"
-- existir), estes dois comandos adicionam a coluna sem apagar nada.
alter table profiles add column if not exists role text not null default 'customer';
alter table profiles add column if not exists plan text not null default 'trial';

alter table profiles enable row level security;

-- ── Função auxiliar: is_admin() ──────────────────────────────────────────
--
-- PARA APRENDER: por que uma função, e não só repetir a checagem em cada
-- política?
--
-- "security definer" faz essa função rodar com permissão elevada,
-- ignorando RLS só para ESSA checagem pontual — evitando um problema
-- comum chamado "recursão de política" (a política de profiles
-- precisando consultar profiles para se validar). Além disso, criar uma
-- função só uma vez e reutilizar em várias políticas é mais fácil de
-- manter do que copiar e colar a mesma condição em 5 lugares.
create or replace function is_admin()
returns boolean as $$
  select exists (
    select 1 from profiles where id = auth.uid() and role = 'admin'
  );
$$ language sql security definer stable;

-- ── Políticas de profiles ─────────────────────────────────────────────────
drop policy if exists "usuario_le_proprio_perfil" on profiles;
drop policy if exists "admin_le_todos_perfis" on profiles;
drop policy if exists "admin_atualiza_todos_perfis" on profiles;

-- Cliente comum: só enxerga a própria linha.
create policy "usuario_le_proprio_perfil"
  on profiles for select
  using (auth.uid() = id);

-- Admin: enxerga TODAS as linhas (para o painel /admin listar empresas).
create policy "admin_le_todos_perfis"
  on profiles for select
  using (is_admin());

-- Admin: pode atualizar qualquer linha (para ativar/suspender empresas).
-- Repare que o cliente comum não tem NENHUMA política de update — ele
-- não consegue, nem por engano, ligar/desligar a própria conta.
create policy "admin_atualiza_todos_perfis"
  on profiles for update
  using (is_admin())
  with check (is_admin());

-- Cria automaticamente um "profile" toda vez que alguém se cadastra.
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, company_name)
  values (new.id, new.raw_user_meta_data->>'company_name');
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();

-- ── Políticas de kv_store ──────────────────────────────────────────────────
--
-- Duas políticas permissivas (o Postgres combina com "OU" entre elas):
--   1) dono do dado + conta ativa → acesso normal do dia a dia
--   2) admin → acesso total, para dar suporte a qualquer empresa
drop policy if exists "usuarios_veem_apenas_seus_dados" on kv_store;
drop policy if exists "usuarios_ativos_veem_apenas_seus_dados" on kv_store;
drop policy if exists "admin_acessa_tudo_kv_store" on kv_store;

create policy "usuarios_ativos_veem_apenas_seus_dados"
  on kv_store
  for all
  using (
    auth.uid() = user_id
    and exists (select 1 from profiles where profiles.id = auth.uid() and profiles.active = true)
  )
  with check (
    auth.uid() = user_id
    and exists (select 1 from profiles where profiles.id = auth.uid() and profiles.active = true)
  );

create policy "admin_acessa_tudo_kv_store"
  on kv_store
  for all
  using (is_admin())
  with check (is_admin());

-- ── Atualiza updated_at automaticamente ──────────────────────────────────
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists kv_store_set_updated_at on kv_store;
create trigger kv_store_set_updated_at
  before update on kv_store
  for each row
  execute function set_updated_at();

-- ═══════════════════════════════════════════════════════════════════════
-- ÚLTIMO PASSO MANUAL — promover sua própria conta a admin.
-- Troque o e-mail abaixo pelo que você usou para se cadastrar no LocFleet,
-- e rode este comando UMA VEZ, depois de já ter criado sua conta pela
-- tela de login normal.
-- ═══════════════════════════════════════════════════════════════════════
-- update profiles set role = 'admin'
-- where id = (select id from auth.users where email = 'seu-email@aqui.com');
