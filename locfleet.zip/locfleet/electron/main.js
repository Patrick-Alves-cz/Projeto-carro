const { app, BrowserWindow, Menu, shell, ipcMain } = require('electron')
const path = require('path')
const fs = require('fs')

const isDev = !app.isPackaged

// ── Data directory ──────────────────────────────────────────────────────────
// userData is the OS-standard location for app data:
//   macOS  → ~/Library/Application Support/RufinoRentCar/
//   Windows → C:\Users\<name>\AppData\Roaming\RufinoRentCar\
// It survives app updates and uninstalls (unless the user explicitly deletes it).
const DATA_DIR = path.join(app.getPath('userData'), 'data')
const DATA_FILE = path.join(DATA_DIR, 'rufino-rent-car.json')

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true })
}

function readStore() {
  ensureDataDir()
  try {
    if (!fs.existsSync(DATA_FILE)) return {}
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8'))
  } catch {
    return {}
  }
}

function writeStore(data) {
  ensureDataDir()
  // Write to a temp file first, then rename — this prevents data corruption
  // if the computer loses power exactly while writing (atomic write pattern).
  const tmp = DATA_FILE + '.tmp'
  fs.writeFileSync(tmp, JSON.stringify(data), 'utf-8')
  fs.renameSync(tmp, DATA_FILE)
}

// ── IPC handlers (called from the renderer via the preload bridge) ───────────
// These let the React app read/write real files on the OS, while keeping
// Node.js APIs completely out of the renderer process (security best practice).

ipcMain.handle('store:get', (_event, key) => {
  const store = readStore()
  return store[key] ?? null
})

ipcMain.handle('store:set', (_event, key, value) => {
  const store = readStore()
  store[key] = value
  writeStore(store)
  return true
})

ipcMain.handle('store:remove', (_event, key) => {
  const store = readStore()
  delete store[key]
  writeStore(store)
  return true
})

ipcMain.handle('store:getAll', () => {
  return readStore()
})

ipcMain.handle('store:setAll', (_event, data) => {
  writeStore(data)
  return true
})

ipcMain.handle('store:dataPath', () => DATA_FILE)

// ── Window ───────────────────────────────────────────────────────────────────
let mainWindow = null

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 680,
    backgroundColor: '#08080A',
    autoHideMenuBar: true,
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    show: false,
  })

  mainWindow.once('ready-to-show', () => mainWindow.show())

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('http')) {
      shell.openExternal(url)
      return { action: 'deny' }
    }
    return { action: 'allow' }
  })

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173')
    mainWindow.webContents.openDevTools({ mode: 'detach' })
  } else {
    mainWindow.loadFile(path.join(__dirname, '..', 'dist', 'index.html'))
  }

  Menu.setApplicationMenu(null)
}

app.whenReady().then(createWindow)

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit()
})

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow()
})
