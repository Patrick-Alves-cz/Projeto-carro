// electron/main.cjs
// Uses .cjs extension because package.json has "type":"module" for the
// React/Vite side — Electron's main process must stay CommonJS.
const { app, BrowserWindow, Menu, shell, ipcMain } = require('electron')
const path = require('path')
const fs = require('fs')

const isDev = !app.isPackaged

// ┌───────────────────────────────────────────────────────────────────────┐
// │  PARA APRENDER: por que fixar o nome do app explicitamente?           │
// │                                                                       │
// │  O Electron usa o nome do produto para decidir ONDE salvar os dados   │
// │  do usuário (ex: C:\Users\...\AppData\Roaming\<nome do app>\).        │
// │  Se esse nome mudar (como agora, de "Rufino Rent Car" para           │
// │  "LocFleet"), um app já instalado apontaria pra uma pasta NOVA e      │
// │  vazia — parecendo que todos os dados sumiram, quando na verdade só   │
// │  estão "no endereço antigo". app.setName() fixa esse nome de forma    │
// │  explícita e previsível, e o bloco de migração abaixo copia os dados  │
// │  da pasta antiga automaticamente na primeira vez que o app novo abre. │
// └───────────────────────────────────────────────────────────────────────┘
app.setName('LocFleet')

// ── Data directory ──────────────────────────────────────────────────────────
const DATA_DIR = path.join(app.getPath('userData'), 'data')
const DATA_FILE = path.join(DATA_DIR, 'rufino-rent-car.json')

// Onde os dados ficavam ANTES deste rebrand (mesmo Roaming/Application
// Support, só que na pasta com o nome antigo do produto).
const LEGACY_DATA_FILE = path.join(path.dirname(app.getPath('userData')), 'Rufino Rent Car', 'data', 'rufino-rent-car.json')

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true })
}

function migrateLegacyDataIfNeeded() {
  ensureDataDir()
  const alreadyHasNewData = fs.existsSync(DATA_FILE)
  const hasLegacyData = fs.existsSync(LEGACY_DATA_FILE)
  if (!alreadyHasNewData && hasLegacyData) {
    fs.copyFileSync(LEGACY_DATA_FILE, DATA_FILE)
    console.info('[migração] Dados encontrados na pasta antiga (Rufino Rent Car) — copiados para a pasta do LocFleet.')
  }
}

function readStore() {
  ensureDataDir()
  try {
    if (!fs.existsSync(DATA_FILE)) return {}
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8'))
  } catch {
    return {}
  }
}

function writeStore(data) {
  ensureDataDir()
  // Atomic write: write to temp file first, then rename.
  // Prevents data corruption if the computer loses power mid-write.
  const tmp = DATA_FILE + '.tmp'
  fs.writeFileSync(tmp, JSON.stringify(data), 'utf-8')
  fs.renameSync(tmp, DATA_FILE)
}

// ── IPC handlers ─────────────────────────────────────────────────────────────
ipcMain.handle('store:get', (_event, key) => {
  const store = readStore()
  return store[key] ?? null
})

ipcMain.handle('store:set', (_event, key, value) => {
  const store = readStore()
  store[key] = value
  writeStore(store)
  return true
})

ipcMain.handle('store:remove', (_event, key) => {
  const store = readStore()
  delete store[key]
  writeStore(store)
  return true
})

ipcMain.handle('store:getAll', () => {
  return readStore()
})

ipcMain.handle('store:setAll', (_event, data) => {
  writeStore(data)
  return true
})

ipcMain.handle('store:dataPath', () => DATA_FILE)

// ── Window ────────────────────────────────────────────────────────────────────
let mainWindow = null

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 680,
    backgroundColor: '#08080A',
    autoHideMenuBar: true,
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    show: false,
  })

  mainWindow.once('ready-to-show', () => mainWindow.show())

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('http')) {
      shell.openExternal(url)
      return { action: 'deny' }
    }
    return { action: 'allow' }
  })

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173')
    mainWindow.webContents.openDevTools({ mode: 'detach' })
  } else {
    mainWindow.loadFile(path.join(__dirname, '..', 'dist', 'index.html'))
  }

  Menu.setApplicationMenu(null)
}

app.whenReady().then(() => {
  migrateLegacyDataIfNeeded()
  createWindow()
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit()
})

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow()
})
