/**
 * preload.js — the secure bridge between the Electron Node.js world and
 * the React renderer world.
 *
 * Security model (important for understanding):
 *   - The renderer (React) has NO direct access to Node.js or the file system.
 *   - Only the specific functions listed in contextBridge.exposeInMainWorld
 *     are available to React, nothing else.
 *   - Every call goes: React → preload bridge → ipcRenderer → main process
 *     → actual file system operation.
 *
 * This is the same pattern used by VSCode, Slack, Figma, and most
 * professional Electron apps.
 */
const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('electronStore', {
  get:     (key)        => ipcRenderer.invoke('store:get', key),
  set:     (key, value) => ipcRenderer.invoke('store:set', key, value),
  remove:  (key)        => ipcRenderer.invoke('store:remove', key),
  getAll:  ()           => ipcRenderer.invoke('store:getAll'),
  setAll:  (data)       => ipcRenderer.invoke('store:setAll', data),
  dataPath: ()          => ipcRenderer.invoke('store:dataPath'),
})

contextBridge.exposeInMainWorld('rufinoDesktop', {
  isDesktopApp: true,
})
