// electron/preload.cjs
// .cjs extension required — see main.cjs for explanation.
const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('electronStore', {
  get:      (key)        => ipcRenderer.invoke('store:get', key),
  set:      (key, value) => ipcRenderer.invoke('store:set', key, value),
  remove:   (key)        => ipcRenderer.invoke('store:remove', key),
  getAll:   ()           => ipcRenderer.invoke('store:getAll'),
  setAll:   (data)       => ipcRenderer.invoke('store:setAll', data),
  dataPath: ()           => ipcRenderer.invoke('store:dataPath'),
})

contextBridge.exposeInMainWorld('rufinoDesktop', {
  isDesktopApp: true,
})
