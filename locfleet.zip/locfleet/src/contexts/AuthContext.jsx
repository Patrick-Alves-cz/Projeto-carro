import { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { supabase, isSupabaseConfigured } from '../services/supabaseClient'
import { setSupabaseUser } from '../services/storageAdapter'

const AuthContext = createContext(null)

/**
 * AuthProvider
 *
 * PARA APRENDER: por que checar "active" aqui, se o banco (RLS) já
 * bloqueia os dados de uma conta suspensa?
 *
 * Segurança em camadas — nunca confie em só um lugar. O RLS no Postgres
 * é a trava de verdade (mesmo alguém "hackeando" o app pelo navegador,
 * não consegue ler dados de uma conta inativa). Mas se a gente não
 * checar isso aqui também, o app do cliente suspenso ficaria preso numa
 * tela vazia e confusa, sem entender por quê. Então:
 *
 *   - RLS no banco  → segurança de verdade, não pode ser burlada
 *   - Checagem aqui → experiência boa: avisa a pessoa com clareza
 *
 * O mesmo raciocínio vale para "isAdmin": a rota /admin aqui no front
 * só esconde o menu e redireciona quem não é admin — quem realmente
 * impede um cliente comum de ler dados de outra empresa é a política
 * "admin_le_todos_perfis" no banco, que só libera para quem tem
 * role='admin' de verdade na tabela profiles.
 */
export function AuthProvider({ children }) {
  const [session, setSession] = useState(null)
  const [ready, setReady] = useState(false)
  const [suspended, setSuspended] = useState(false)
  const [isAdmin, setIsAdmin] = useState(false)

  const fetchProfileStatus = useCallback(async (userId) => {
    if (!userId) return { active: true, isAdmin: false }
    const { data, error } = await supabase.from('profiles').select('active, role').eq('id', userId).maybeSingle()
    if (error) {
      // Se a checagem falhar por erro de rede, não bloqueia o acesso —
      // evita deixar alguém legítimo trancado fora por instabilidade.
      console.error('[auth] Falha ao checar status da conta', error)
      return { active: true, isAdmin: false }
    }
    return { active: data?.active !== false, isAdmin: data?.role === 'admin' }
  }, [])

  useEffect(() => {
    if (!isSupabaseConfigured) {
      // Sem nuvem configurada: não existe conceito de "login" — o app
      // local (Electron/localStorage) sempre está "autenticado".
      setSession({ local: true })
      setReady(true)
      return
    }

    async function handleSession(newSession) {
      const userId = newSession?.user?.id ?? null

      if (userId) {
        const status = await fetchProfileStatus(userId)
        if (!status.active) {
          setSuspended(true)
          setIsAdmin(false)
          setSupabaseUser(null)
          await supabase.auth.signOut()
          setSession(null)
          return
        }
        setIsAdmin(status.isAdmin)
      } else {
        setIsAdmin(false)
      }

      setSuspended(false)
      setSession(newSession)
      setSupabaseUser(userId)
    }

    supabase.auth.getSession().then(({ data }) => {
      handleSession(data.session).finally(() => setReady(true))
    })

    const { data: listener } = supabase.auth.onAuthStateChange((_event, newSession) => {
      handleSession(newSession)
    })

    return () => listener.subscription.unsubscribe()
  }, [fetchProfileStatus])

  async function signIn(email, password) {
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) throw error
  }

  async function signUp(email, password, companyName) {
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { company_name: companyName } },
    })
    if (error) throw error
  }

  async function signOut() {
    if (isSupabaseConfigured) await supabase.auth.signOut()
  }

  const value = {
    session,
    ready,
    suspended,
    isAdmin,
    isAuthenticated: Boolean(session),
    cloudEnabled: isSupabaseConfigured,
    signIn,
    signUp,
    signOut,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth deve ser usado dentro de um AuthProvider')
  return ctx
}
