import { supabase, isSupabaseConfigured } from './supabaseClient'

/**
 * storageAdapter.js — armazenamento em 3 níveis
 *
 * ┌─────────────────────────────────────────────────────────────────────┐
 * │  PARA APRENDER: como o app escolhe onde salvar?                     │
 * │                                                                     │
 * │  1º) Supabase (nuvem) — se as chaves estiverem configuradas E tiver │
 * │      alguém logado. Usado na versão web (Vercel).                   │
 * │                                                                     │
 * │  2º) Electron (arquivo local) — se estiver rodando como app         │
 * │      desktop instalado (o .exe do seu pai).                         │
 * │                                                                     │
 * │  3º) localStorage (navegador) — sobra para quando nenhum dos dois   │
 * │      acima está disponível (ex: você rodando `npm run dev` sem      │
 * │      configurar Supabase, só testando local).                       │
 * │                                                                     │
 * │  O app do seu pai foi compilado (.exe) SEM as variáveis do          │
 * │  Supabase configuradas — então ele cai automaticamente no nível 2   │
 * │  e nunca nem sabe que a nuvem existe. Nada nele muda.               │
 * └─────────────────────────────────────────────────────────────────────┘
 */

const NAMESPACE = 'locfleet'
const SCHEMA_VERSION = 2

const isElectron = typeof window !== 'undefined' && !!window.electronStore

// Preenchido pelo AuthContext assim que alguém faz login — veja
// setSupabaseUser() no final deste arquivo.
let currentUserId = null

export function setSupabaseUser(userId) {
  currentUserId = userId
}

// ── Nível 1: Supabase (nuvem) ────────────────────────────────────────────────

const supabaseAdapter = {
  async get(key, fallback = null) {
    if (!currentUserId) return fallback
    const { data, error } = await supabase
      .from('kv_store')
      .select('value')
      .eq('user_id', currentUserId)
      .eq('key', key)
      .maybeSingle()
    if (error) {
      console.error(`[supabase] Falha ao ler "${key}"`, error)
      return fallback
    }
    return data?.value ?? fallback
  },

  // Todo objeto que passa por aqui — veículo, cliente, locação, despesa,
  // contrato, pagamento de motorista, o que for — é automaticamente
  // marcado com o tenant (user_id) de quem está logado, porque toda a
  // aplicação (todos os *Service.js) grava dados chamando esta mesma
  // função. Não existe um "esqueci de marcar o tenant nesta tela": é
  // estruturalmente impossível gravar algo sem essa marcação.
  async set(key, value) {
    if (!currentUserId) return false
    const { error } = await supabase
      .from('kv_store')
      .upsert({ user_id: currentUserId, key, value }, { onConflict: 'user_id,key' })
    if (error) {
      console.error(`[supabase] Falha ao gravar "${key}"`, error)
      return false
    }
    return true
  },

  async remove(key) {
    if (!currentUserId) return true
    await supabase.from('kv_store').delete().eq('user_id', currentUserId).eq('key', key)
    return true
  },

  async clearAll() {
    if (!currentUserId) return true
    await supabase.from('kv_store').delete().eq('user_id', currentUserId)
    return true
  },

  async exportAll() {
    if (!currentUserId) return { schemaVersion: SCHEMA_VERSION, exportedAt: new Date().toISOString(), data: {} }
    const { data: rows } = await supabase.from('kv_store').select('key, value').eq('user_id', currentUserId)
    const data = {}
    ;(rows || []).forEach((row) => {
      data[row.key] = row.value
    })
    return { schemaVersion: SCHEMA_VERSION, exportedAt: new Date().toISOString(), data }
  },

  async importAll(payload) {
    if (!payload?.data || !currentUserId) throw new Error('Arquivo de backup inválido')
    const rows = Object.entries(payload.data).map(([key, value]) => ({ user_id: currentUserId, key, value }))
    if (rows.length === 0) return true
    const { error } = await supabase.from('kv_store').upsert(rows, { onConflict: 'user_id,key' })
    if (error) throw error
    return true
  },
}

// ── Nível 2: Electron (arquivo local) ────────────────────────────────────────

const electronAdapter = {
  async get(key, fallback = null) {
    try {
      const value = await window.electronStore.get(key)
      return value ?? fallback
    } catch {
      return fallback
    }
  },
  async set(key, value) {
    try {
      await window.electronStore.set(key, value)
      return true
    } catch (err) {
      console.error(`[electron-store] Falha ao gravar "${key}"`, err)
      return false
    }
  },
  async remove(key) {
    try {
      await window.electronStore.remove(key)
      return true
    } catch {
      return true
    }
  },
  async clearAll() {
    await window.electronStore.setAll({})
    return true
  },
  async exportAll() {
    const data = await window.electronStore.getAll()
    return { schemaVersion: SCHEMA_VERSION, exportedAt: new Date().toISOString(), data }
  },
  async importAll(payload) {
    if (!payload?.data) throw new Error('Arquivo de backup inválido')
    await window.electronStore.setAll(payload.data)
    return true
  },
}

// ── Nível 3: localStorage (navegador, modo dev sem nuvem) ───────────────────

function nsKey(key) {
  return `${NAMESPACE}:${key}`
}

const localStorageAdapter = {
  async get(key, fallback = null) {
    try {
      const raw = window.localStorage.getItem(nsKey(key))
      if (raw === null) return fallback
      return JSON.parse(raw)
    } catch {
      return fallback
    }
  },
  async set(key, value) {
    try {
      window.localStorage.setItem(nsKey(key), JSON.stringify(value))
      return true
    } catch (err) {
      console.error(`[localStorage] Falha ao gravar "${key}"`, err)
      return false
    }
  },
  async remove(key) {
    window.localStorage.removeItem(nsKey(key))
    return true
  },
  async clearAll() {
    Object.keys(window.localStorage)
      .filter((k) => k.startsWith(`${NAMESPACE}:`))
      .forEach((k) => window.localStorage.removeItem(k))
    return true
  },
  async exportAll() {
    const data = {}
    Object.keys(window.localStorage)
      .filter((k) => k.startsWith(`${NAMESPACE}:`))
      .forEach((k) => {
        const shortKey = k.replace(`${NAMESPACE}:`, '')
        try {
          data[shortKey] = JSON.parse(window.localStorage.getItem(k))
        } catch {
          data[shortKey] = window.localStorage.getItem(k)
        }
      })
    return { schemaVersion: SCHEMA_VERSION, exportedAt: new Date().toISOString(), data }
  },
  async importAll(payload) {
    if (!payload?.data) throw new Error('Arquivo de backup inválido')
    Object.entries(payload.data).forEach(([shortKey, value]) => {
      window.localStorage.setItem(nsKey(shortKey), JSON.stringify(value))
    })
    return true
  },
}

// ── Escolhe o adaptador certo, uma vez, na inicialização ────────────────────

function pickMode() {
  if (isSupabaseConfigured) return 'supabase'
  if (isElectron) return 'electron'
  return 'localStorage'
}

const mode = pickMode()
const adapters = { supabase: supabaseAdapter, electron: electronAdapter, localStorage: localStorageAdapter }

export const storageAdapter = adapters[mode]
storageAdapter.schemaVersion = SCHEMA_VERSION
storageAdapter.mode = mode
storageAdapter.isElectron = mode === 'electron'
storageAdapter.isCloud = mode === 'supabase'

if (typeof window !== 'undefined') {
  const labels = { supabase: '☁️ Supabase (nuvem)', electron: '🖥 Electron (arquivo)', localStorage: '🌐 Navegador (localStorage)' }
  console.info(`[storage] Modo: ${labels[mode]}`)
}
