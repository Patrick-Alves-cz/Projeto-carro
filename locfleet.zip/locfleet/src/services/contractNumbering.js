import { storageAdapter } from './storageAdapter'

const COUNTER_KEY = 'contractCounters'

/**
 * getNextContractNumber — atomically-ish reserves the next sequential
 * number for the given year. Numbers are never reused, even if a
 * contract is later deleted, because the counter is independent from the
 * contracts collection itself.
 */
export async function getNextContractNumber(date = new Date()) {
  const year = date.getFullYear()
  const counters = await storageAdapter.get(COUNTER_KEY, {})
  const next = (counters[year] || 0) + 1
  await storageAdapter.set(COUNTER_KEY, { ...counters, [year]: next })
  const sequence = String(next).padStart(6, '0')
  return `RRC-${year}-${sequence}`
}
