import { storageAdapter } from './storageAdapter'
import { DEFAULT_CONTRACT_CLAUSES } from '../utils/contractTemplate'

const KEY = 'settings'

// Bumped whenever DEFAULT_CONTRACT_CLAUSES or the legal name changes so
// that browsers with data saved from an earlier version automatically
// pick up the new contract template on next load — see the migration in
// get() below. A person's own edits to *other* fields (CNPJ, phone,
// address, etc.) are never touched by this.
const CONTRACT_TEMPLATE_VERSION = 2

const DEFAULT_SETTINGS = {
  companyName: 'Rufino Rent Car',
  legalName: 'RUFINO MOBILIDADE E GESTÃO LTDA',
  cnpj: '55.035.977/0001-36',
  ownerName: 'Magno Rufino',
  phone: '',
  email: '',
  address: '',
  contractCity: '',
  logo: '',
  alertThresholdDays: 30,
  contractClauses: DEFAULT_CONTRACT_CLAUSES,
  contractTemplateVersion: CONTRACT_TEMPLATE_VERSION,
}

export const settingsService = {
  async get() {
    const saved = await storageAdapter.get(KEY, null)
    let merged = { ...DEFAULT_SETTINGS, ...(saved || {}) }

    const savedVersion = saved?.contractTemplateVersion || 0
    if (savedVersion < CONTRACT_TEMPLATE_VERSION) {
      // Upgrade only the contract text itself — every other setting
      // (CNPJ, phone, address, contractCity...) is left exactly as saved.
      merged = {
        ...merged,
        legalName: DEFAULT_SETTINGS.legalName,
        contractClauses: DEFAULT_CONTRACT_CLAUSES,
        contractTemplateVersion: CONTRACT_TEMPLATE_VERSION,
      }
      await storageAdapter.set(KEY, merged)
    }

    return merged
  },
  async update(patch) {
    const current = await this.get()
    const next = { ...current, ...patch }
    await storageAdapter.set(KEY, next)
    return next
  },
  defaults: DEFAULT_SETTINGS,
}
