import { createClient } from '@supabase/supabase-js'

/**
 * supabaseClient.js
 *
 * ┌─────────────────────────────────────────────────────────────────────┐
 * │  PARA APRENDER: o que é isso?                                       │
 * │                                                                     │
 * │  Supabase é um "Postgres gerenciado" — um banco de dados de verdade │
 * │  (o mesmo tipo que empresas grandes usam) rodando na nuvem, com     │
 * │  login/autenticação e regras de segurança já prontas.               │
 * │                                                                     │
 * │  As duas variáveis abaixo (URL e ANON_KEY) são como o "endereço"    │
 * │  e a "senha pública" do seu banco. Elas NÃO são segredos perigosos  │
 * │  — a segurança de verdade vem do Row Level Security (RLS), que      │
 * │  configuramos no banco: mesmo que alguém descubra essas chaves,     │
 * │  só consegue ver os próprios dados de quem estiver logado.          │
 * │                                                                     │
 * │  Isso é diferente de uma "chave secreta de admin" — essa nunca      │
 * │  deve aparecer no código do navegador.                              │
 * └─────────────────────────────────────────────────────────────────────┘
 *
 * As variáveis vêm de um arquivo `.env` local (que você cria, nunca vai
 * para o GitHub) ou das variáveis de ambiente configuradas no Vercel.
 * Veja o arquivo `.env.example` na raiz do projeto.
 */

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

// isSupabaseConfigured é usado pelo storageAdapter para decidir se deve
// usar a nuvem ou cair de volta para o armazenamento local — assim o app
// do seu pai (build sem essas variáveis) nunca quebra por falta delas.
export const isSupabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey)

export const supabase = isSupabaseConfigured
  ? createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    })
  : null
