import { createRepository } from './repository'

const accountRepo = createRepository('driverAccounts')
const paymentRepo = createRepository('driverPayments')

export const driverAccountService = {
  list: accountRepo.list,
  get: accountRepo.get,
  update: accountRepo.update,
  remove: accountRepo.remove,

  findByClient: async (clientId) => {
    const items = await accountRepo.list()
    return items.find((a) => a.clientId === clientId) ?? null
  },

  /** getOrCreate — every client gets a lazily-created account the first time it's opened. */
  getOrCreate: async (clientId, defaults = {}) => {
    const existing = await driverAccountService.findByClient(clientId)
    if (existing) return existing
    return accountRepo.create({
      clientId,
      dailyRate: 100,
      startDate: new Date().toISOString(),
      active: true,
      notes: '',
      ...defaults,
    })
  },
}

export const driverPaymentService = {
  list: paymentRepo.list,
  create: (data) => paymentRepo.create({ notes: '', method: 'dinheiro', ...data }),
  update: paymentRepo.update,
  remove: paymentRepo.remove,

  listByClient: async (clientId) => {
    const items = await paymentRepo.list()
    return items.filter((p) => p.clientId === clientId).sort((a, b) => new Date(b.date) - new Date(a.date))
  },
}
