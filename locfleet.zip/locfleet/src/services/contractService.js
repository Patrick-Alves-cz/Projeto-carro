import { createRepository } from './repository'
import { getNextContractNumber } from './contractNumbering'

const repo = createRepository('contracts')

export const contractService = {
  list: repo.list,
  get: repo.get,
  remove: repo.remove,

  findByRental: async (rentalId) => {
    const items = await repo.list()
    return items.find((c) => c.rentalId === rentalId) ?? null
  },

  /**
   * issue — creates a new contract with a fresh sequential number and an
   * immutable snapshot of all the data that composes the document. Once
   * issued, a contract never changes even if the client/vehicle/rental
   * records are edited later — exactly like a real paper contract.
   */
  issue: async (snapshotWithoutNumber) => {
    const contractNumber = await getNextContractNumber()
    return repo.create({
      contractNumber,
      issuedAt: new Date().toISOString(),
      status: 'emitido',
      ...snapshotWithoutNumber,
    })
  },
}
