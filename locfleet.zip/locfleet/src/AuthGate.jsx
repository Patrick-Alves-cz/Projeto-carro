import { Routes, Route } from 'react-router-dom'
import { useAuth } from './contexts/AuthContext.jsx'
import { DataProvider } from './contexts/DataContext.jsx'
import LoginPage from './pages/LoginPage.jsx'
import SuspendedPage from './pages/SuspendedPage.jsx'
import AdminPage from './pages/AdminPage.jsx'
import LoadingScreen from './components/ui/LoadingScreen.jsx'
import App from './App.jsx'

/**
 * AuthGate — decide o que mostrar antes mesmo do resto do app carregar:
 *
 *   1. Ainda checando sessão salva?        → tela de carregamento
 *   2. Conta foi suspensa (inadimplência)? → tela de acesso suspenso
 *   3. Nuvem configurada e ninguém logado? → tela de login
 *   4. Rota /admin?                        → painel admin (sem DataProvider —
 *      ele não trabalha com dados de uma empresa específica, então não
 *      precisa esperar o carregamento de veículos/clientes/etc.)
 *   5. Qualquer outra rota, autenticado?   → app normal, com DataProvider
 */
export default function AuthGate() {
  const { ready, isAuthenticated, cloudEnabled, suspended } = useAuth()

  if (!ready) return <LoadingScreen label="Verificando sessão..." />
  if (suspended) return <SuspendedPage />
  if (cloudEnabled && !isAuthenticated) return <LoginPage />

  return (
    <Routes>
      <Route path="/admin" element={<AdminPage />} />
      <Route
        path="/*"
        element={
          <DataProvider>
            <App />
          </DataProvider>
        }
      />
    </Routes>
  )
}
