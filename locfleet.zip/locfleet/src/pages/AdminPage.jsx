import { useEffect, useMemo, useState } from 'react'
import { Navigate } from 'react-router-dom'
import { Building2, Users, ShieldCheck, ShieldOff, Loader2 } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext.jsx'
import { useToast } from '../contexts/ToastContext.jsx'
import { useConfirm } from '../contexts/ConfirmContext.jsx'
import { supabase } from '../services/supabaseClient'
import { BrandMark } from '../components/shared/Logo.jsx'
import { formatDate } from '../utils/formatters'

/**
 * AdminPage — painel interno, só para você.
 *
 * PARA APRENDER: por que essa página consulta o Supabase direto, em vez
 * de usar o DataContext como todo o resto do sistema?
 *
 * O DataContext (e o storageAdapter por trás dele) foi construído para
 * ser "tenant-scoped" de propósito — ele só enxerga os dados da empresa
 * logada, e isso é uma característica de segurança, não uma limitação.
 * O painel admin precisa enxergar TODAS as empresas, então ele usa um
 * caminho separado, elevado, que só funciona porque a política
 * "admin_le_todos_perfis" no banco libera isso — e só libera mesmo pra
 * quem tem role='admin' de verdade. Duas responsabilidades diferentes,
 * dois caminhos diferentes.
 */
export default function AdminPage() {
  const { isAdmin, signOut } = useAuth()
  const toast = useToast()
  const confirm = useConfirm()
  const [companies, setCompanies] = useState([])
  const [loading, setLoading] = useState(true)
  const [togglingId, setTogglingId] = useState(null)

  useEffect(() => {
    if (!isAdmin) return
    loadCompanies()
  }, [isAdmin])

  async function loadCompanies() {
    setLoading(true)
    const { data, error } = await supabase.from('profiles').select('*').order('created_at', { ascending: false })
    if (error) {
      toast.error('Não foi possível carregar as empresas')
    } else {
      setCompanies(data || [])
    }
    setLoading(false)
  }

  const stats = useMemo(() => {
    const total = companies.length
    const active = companies.filter((c) => c.active).length
    return { total, active, suspended: total - active }
  }, [companies])

  async function handleToggle(company) {
    const willSuspend = company.active
    const ok = await confirm({
      title: willSuspend ? 'Suspender empresa?' : 'Reativar empresa?',
      description: willSuspend
        ? `${company.company_name || 'Esta empresa'} perderá o acesso ao sistema imediatamente.`
        : `${company.company_name || 'Esta empresa'} volta a ter acesso normal ao sistema.`,
      confirmLabel: willSuspend ? 'Suspender' : 'Reativar',
      tone: willSuspend ? 'danger' : 'default',
    })
    if (!ok) return

    setTogglingId(company.id)
    const { error } = await supabase.from('profiles').update({ active: !company.active }).eq('id', company.id)
    if (error) {
      toast.error('Não foi possível atualizar o status')
    } else {
      setCompanies((prev) => prev.map((c) => (c.id === company.id ? { ...c, active: !c.active } : c)))
      toast.success(willSuspend ? 'Empresa suspensa' : 'Empresa reativada')
    }
    setTogglingId(null)
  }

  // Proteção no front: esconde a tela de quem não é admin. A proteção
  // de verdade (quem consegue LER os dados de outras empresas) é a
  // política de RLS no banco — isto aqui é só experiência de uso.
  if (!isAdmin) return <Navigate to="/" replace />

  return (
    <div className="min-h-screen bg-ink-950 px-6 py-8">
      <div className="mx-auto max-w-4xl">
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BrandMark size={28} />
            <div>
              <p className="font-display text-[16px] font-bold text-mist-50">Painel administrativo</p>
              <p className="text-[12px] text-mist-400">Visível apenas para contas com função de administrador</p>
            </div>
          </div>
          <button
            onClick={signOut}
            className="rounded-lg border border-ink-600 px-3 py-1.5 text-[12.5px] text-mist-400 transition-colors hover:bg-ink-800 hover:text-mist-100"
          >
            Sair
          </button>
        </div>

        <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
          <StatCard icon={Building2} label="Total de empresas" value={stats.total} tone="brand" />
          <StatCard icon={ShieldCheck} label="Empresas ativas" value={stats.active} tone="emerald" />
          <StatCard icon={ShieldOff} label="Empresas suspensas" value={stats.suspended} tone="ruby" />
        </div>

        <div className="surface-card overflow-hidden">
          <div className="flex items-center gap-1.5 border-b border-ink-700 px-5 py-3.5">
            <Users size={14} className="text-mist-400" />
            <p className="label-eyebrow">Empresas cadastradas</p>
          </div>

          {loading ? (
            <div className="flex items-center justify-center gap-2 py-12 text-mist-400">
              <Loader2 size={16} className="animate-spin" /> Carregando...
            </div>
          ) : companies.length === 0 ? (
            <p className="px-5 py-8 text-center text-[13px] text-mist-400">Nenhuma empresa cadastrada ainda.</p>
          ) : (
            <table className="w-full text-left text-[13px]">
              <thead>
                <tr className="border-b border-ink-700 bg-ink-800/60 text-[11px] uppercase tracking-wide text-mist-400">
                  <th className="px-5 py-3 font-medium">Empresa</th>
                  <th className="px-5 py-3 font-medium">Plano</th>
                  <th className="px-5 py-3 font-medium">Cadastro</th>
                  <th className="px-5 py-3 font-medium">Status</th>
                  <th className="px-5 py-3 font-medium"></th>
                </tr>
              </thead>
              <tbody>
                {companies.map((c) => (
                  <tr key={c.id} className="border-b border-ink-800 last:border-0 hover:bg-ink-800/40">
                    <td className="px-5 py-3 text-mist-100">
                      {c.company_name || 'Sem nome informado'}
                      {c.role === 'admin' && (
                        <span className="ml-2 rounded-full bg-brand-500/10 px-2 py-0.5 text-[10.5px] text-brand-400">admin</span>
                      )}
                    </td>
                    <td className="px-5 py-3 capitalize text-mist-300">{c.plan}</td>
                    <td className="px-5 py-3 text-mist-300">{formatDate(c.created_at)}</td>
                    <td className="px-5 py-3">
                      <span
                        className={`rounded-full px-2.5 py-1 text-[11.5px] font-medium ${
                          c.active ? 'bg-emerald-500/10 text-emerald-400' : 'bg-ruby-500/10 text-ruby-400'
                        }`}
                      >
                        {c.active ? 'Ativo' : 'Suspenso'}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-right">
                      {c.role !== 'admin' && (
                        <button
                          onClick={() => handleToggle(c)}
                          disabled={togglingId === c.id}
                          className={`rounded-lg px-3 py-1.5 text-[12px] font-medium transition-colors disabled:opacity-50 ${
                            c.active
                              ? 'text-ruby-400 hover:bg-ruby-500/10'
                              : 'text-emerald-400 hover:bg-emerald-500/10'
                          }`}
                        >
                          {togglingId === c.id ? '...' : c.active ? 'Suspender' : 'Reativar'}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <p className="mt-4 text-center text-[11.5px] text-mist-500">
          Suspender uma empresa bloqueia o acesso a todos os dados dela imediatamente, no banco de dados.
        </p>
      </div>
    </div>
  )
}

function StatCard({ icon: Icon, label, value, tone }) {
  const toneClasses = {
    brand: 'text-brand-400 bg-brand-500/10',
    emerald: 'text-emerald-400 bg-emerald-500/10',
    ruby: 'text-ruby-400 bg-ruby-500/10',
  }
  return (
    <div className="surface-card p-5">
      <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${toneClasses[tone]}`}>
        <Icon size={16} />
      </div>
      <p className="mt-3 font-mono text-[22px] font-semibold text-mist-50">{value}</p>
      <p className="mt-1 text-[12px] text-mist-400">{label}</p>
    </div>
  )
}
