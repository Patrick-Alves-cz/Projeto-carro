import { useEffect, useMemo, useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { ArrowLeft, Users, Trash2, Pencil, Wallet, TrendingUp, TrendingDown, AlertTriangle, CalendarClock, FileDown, Plus, Save } from 'lucide-react'
import { useData } from '../../contexts/DataContext.jsx'
import { useConfirm } from '../../contexts/ConfirmContext.jsx'
import { useToast } from '../../contexts/ToastContext.jsx'
import Badge from '../../components/ui/Badge.jsx'
import Button from '../../components/ui/Button.jsx'
import EmptyState from '../../components/ui/EmptyState.jsx'
import ClientFormModal from '../../components/clients/ClientFormModal.jsx'
import PaymentCalendar from '../../components/clients/PaymentCalendar.jsx'
import RegisterPaymentModal from '../../components/clients/RegisterPaymentModal.jsx'
import { RENTAL_STATUSES, PAYMENT_METHODS, labelFor, colorFor } from '../../utils/constants'
import { formatCurrency, formatDate } from '../../utils/formatters'
import { accountSummary } from '../../utils/driverLedger'
import { exportDriverStatementPDF } from '../../utils/statementExport'

export default function ClientDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const confirm = useConfirm()
  const toast = useToast()
  const {
    clients,
    rentals,
    vehicles,
    settings,
    deleteClient,
    editClient,
    driverAccounts,
    driverPayments,
    getOrCreateDriverAccount,
    updateDriverAccount,
    registerDriverPayment,
  } = useData()

  const client = clients.find((c) => c.id === id)
  const [editOpen, setEditOpen] = useState(false)
  const [paymentOpen, setPaymentOpen] = useState(false)
  const [prefill, setPrefill] = useState({ date: new Date(), amount: null })
  const [rateForm, setRateForm] = useState({ dailyRate: 100, startDate: '' })
  const [savingRate, setSavingRate] = useState(false)

  const account = driverAccounts.find((a) => a.clientId === id) ?? null

  useEffect(() => {
    if (client && !account) {
      getOrCreateDriverAccount(client.id)
    }
  }, [client, account, getOrCreateDriverAccount])

  useEffect(() => {
    if (account) {
      setRateForm({ dailyRate: account.dailyRate, startDate: account.startDate.slice(0, 10) })
    }
  }, [account])

  const clientPayments = useMemo(
    () => driverPayments.filter((p) => p.clientId === id).sort((a, b) => new Date(b.date) - new Date(a.date)),
    [driverPayments, id]
  )

  const summary = useMemo(() => {
    if (!account) return null
    return accountSummary(account, clientPayments)
  }, [account, clientPayments])

  const clientRentals = useMemo(
    () => rentals.filter((r) => r.clientId === id).sort((a, b) => new Date(b.pickupDate) - new Date(a.pickupDate)),
    [rentals, id]
  )

  if (!client) {
    return (
      <EmptyState
        icon={Users}
        title="Cliente não encontrado"
        description="Este cliente pode ter sido removido do cadastro."
        action={<Button onClick={() => navigate('/clientes')}>Voltar para clientes</Button>}
      />
    )
  }

  async function handleDelete() {
    const ok = await confirm({
      title: 'Excluir cliente?',
      description: `${client.name} será removido permanentemente do cadastro.`,
    })
    if (!ok) return
    await deleteClient(client.id)
    toast.success('Cliente excluído com sucesso')
    navigate('/clientes')
  }

  function openPaymentFor(day, entry) {
    const due = entry ? Math.max(0, entry.due - entry.paid) : account?.dailyRate
    setPrefill({ date: day, amount: due })
    setPaymentOpen(true)
  }

  async function handleSaveRate() {
    setSavingRate(true)
    await updateDriverAccount(account.id, {
      dailyRate: Number(rateForm.dailyRate) || 0,
      startDate: new Date(rateForm.startDate).toISOString(),
    })
    setSavingRate(false)
    toast.success('Conta corrente atualizada')
  }

  function handleStatement() {
    if (!account || !summary) return
    exportDriverStatementPDF({ settings, client, account, summary, payments: clientPayments })
    toast.success('Extrato financeiro gerado com sucesso')
  }

  return (
    <div>
      <Link to="/clientes" className="mb-4 inline-flex items-center gap-1.5 text-[12.5px] text-mist-400 hover:text-mist-100">
        <ArrowLeft size={14} /> Voltar para clientes
      </Link>

      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-[20px] font-bold text-mist-50">{client.name}</h1>
          <p className="mt-0.5 text-[13px] text-mist-400">
            CPF <span className="font-mono">{client.cpf}</span> · {client.whatsapp || client.phone || 'sem telefone'}
          </p>
        </div>
        <div className="flex gap-2.5">
          <Button variant="secondary" icon={Pencil} onClick={() => setEditOpen(true)}>Editar</Button>
          <Button variant="danger" icon={Trash2} onClick={handleDelete}>Excluir cliente</Button>
        </div>
      </div>

      {/* Conta corrente do motorista */}
      <div className="surface-card p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <h3 className="label-eyebrow flex items-center gap-1.5"><Wallet size={13} /> Conta corrente do motorista</h3>
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant="secondary" icon={FileDown} onClick={handleStatement}>Gerar extrato financeiro</Button>
            <Button size="sm" icon={Plus} onClick={() => openPaymentFor(new Date(), null)}>Registrar pagamento</Button>
          </div>
        </div>

        {summary && (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <SummaryStat icon={AlertTriangle} tone={summary.balanceDue > 0 ? 'ruby' : 'emerald'} label="Saldo em aberto" value={formatCurrency(summary.balanceDue)} />
            <SummaryStat icon={TrendingUp} tone="emerald" label="Total pago" value={formatCurrency(summary.totalPaid)} />
            <SummaryStat icon={TrendingDown} tone="mist" label="Total devido" value={formatCurrency(summary.totalDue)} />
            <SummaryStat icon={CalendarClock} tone={summary.daysLate > 0 ? 'amber' : 'emerald'} label="Dias em atraso" value={summary.daysLate} />
          </div>
        )}

        <div className="mt-5 grid grid-cols-1 gap-5 lg:grid-cols-2">
          <div className="rounded-xl border border-ink-700 p-4">
            {summary && account && (
              <PaymentCalendar ledger={summary.ledger} accountStart={account.startDate} onSelectDay={openPaymentFor} />
            )}
          </div>

          <div className="flex flex-col gap-4">
            <div className="rounded-xl border border-ink-700 p-4">
              <p className="label-eyebrow mb-3">Configuração da diária</p>
              <div className="grid grid-cols-2 gap-3">
                <label className="block">
                  <span className="mb-1.5 block text-[11.5px] text-mist-400">Valor da diária</span>
                  <input
                    type="number"
                    className="input"
                    value={rateForm.dailyRate}
                    onChange={(e) => setRateForm((f) => ({ ...f, dailyRate: e.target.value }))}
                  />
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-[11.5px] text-mist-400">Início do acompanhamento</span>
                  <input
                    type="date"
                    className="input"
                    value={rateForm.startDate}
                    onChange={(e) => setRateForm((f) => ({ ...f, startDate: e.target.value }))}
                  />
                </label>
              </div>
              <Button size="sm" variant="secondary" icon={Save} loading={savingRate} onClick={handleSaveRate} className="mt-3">
                Salvar
              </Button>
              {summary?.lastPayment && (
                <p className="mt-3 border-t border-ink-700 pt-3 text-[11.5px] text-mist-400">
                  Último pagamento: <span className="text-mist-200">{formatCurrency(summary.lastPayment.amount)}</span> em {formatDate(summary.lastPayment.date)}
                </p>
              )}
            </div>

            <div className="max-h-64 overflow-y-auto rounded-xl border border-ink-700 p-4">
              <p className="label-eyebrow mb-3">Histórico de pagamentos</p>
              {clientPayments.length === 0 ? (
                <p className="text-[12.5px] text-mist-400">Nenhum pagamento registrado ainda.</p>
              ) : (
                <ul className="space-y-2">
                  {clientPayments.map((p) => (
                    <li key={p.id} className="flex items-center justify-between text-[12.5px]">
                      <span className="text-mist-300">{formatDate(p.date)} · {labelFor(PAYMENT_METHODS, p.method)}</span>
                      <span className="font-mono font-medium text-emerald-400">+{formatCurrency(p.amount)}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Client info + rental history */}
      <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="surface-card p-5">
          <h3 className="label-eyebrow mb-3">Dados do cliente</h3>
          <dl className="space-y-2.5 text-[13px]">
            <Row label="RG" value={client.rg} />
            <Row label="CNH" value={client.cnh} />
            <Row label="Validade da CNH" value={formatDate(client.cnhExpiry)} />
            <Row label="Telefone" value={client.phone} />
            <Row label="WhatsApp" value={client.whatsapp} />
            <Row label="E-mail" value={client.email} />
            <Row label="Endereço" value={client.address} />
          </dl>
        </div>

        <div className="surface-card p-5 lg:col-span-2">
          <h3 className="label-eyebrow mb-3">Histórico de locações</h3>
          {clientRentals.length === 0 ? (
            <p className="text-[12.5px] text-mist-400">Este cliente ainda não possui locações registradas.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-[12.5px]">
                <thead>
                  <tr className="border-b border-ink-700 text-[11px] uppercase tracking-wide text-mist-400">
                    <th className="pb-2 pr-4 font-medium">Veículo</th>
                    <th className="pb-2 pr-4 font-medium">Retirada</th>
                    <th className="pb-2 pr-4 font-medium">Devolução</th>
                    <th className="pb-2 pr-4 font-medium">Valor</th>
                    <th className="pb-2 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {clientRentals.map((r) => {
                    const vehicle = vehicles.find((v) => v.id === r.vehicleId)
                    return (
                      <tr key={r.id} className="border-b border-ink-800 last:border-0">
                        <td className="py-2.5 pr-4 text-mist-100">{vehicle ? `${vehicle.brand} ${vehicle.model}` : 'Veículo removido'}</td>
                        <td className="py-2.5 pr-4 text-mist-300">{formatDate(r.pickupDate)}</td>
                        <td className="py-2.5 pr-4 text-mist-300">{formatDate(r.actualReturnDate || r.returnDate)}</td>
                        <td className="py-2.5 pr-4 font-mono text-mist-100">{formatCurrency(r.totalValue)}</td>
                        <td className="py-2.5">
                          <Badge tone={colorFor(RENTAL_STATUSES, r.status)}>{labelFor(RENTAL_STATUSES, r.status)}</Badge>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <ClientFormModal
        open={editOpen}
        onClose={() => setEditOpen(false)}
        client={client}
        onSubmit={async (data) => {
          await editClient(client.id, data)
          toast.success('Cliente atualizado com sucesso')
        }}
      />

      <RegisterPaymentModal
        open={paymentOpen}
        onClose={() => setPaymentOpen(false)}
        defaultDate={prefill.date}
        defaultAmount={prefill.amount}
        onSubmit={async (data) => {
          await registerDriverPayment({ clientId: id, ...data })
          toast.success('Pagamento registrado', { description: 'O saldo da conta corrente foi atualizado.' })
        }}
      />
    </div>
  )
}

function Row({ label, value }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <dt className="text-mist-400">{label}</dt>
      <dd className="text-right text-mist-100">{value || '—'}</dd>
    </div>
  )
}

function SummaryStat({ icon: Icon, tone, label, value }) {
  const toneClasses = {
    brand: 'text-brand-400 bg-brand-500/10',
    emerald: 'text-emerald-400 bg-emerald-500/10',
    ruby: 'text-ruby-400 bg-ruby-500/10',
    amber: 'text-amber-400 bg-amber-500/10',
    mist: 'text-mist-200 bg-ink-700',
  }
  return (
    <div className="rounded-xl border border-ink-700 p-3.5">
      <div className={`flex h-8 w-8 items-center justify-center rounded-lg ${toneClasses[tone]}`}>
        <Icon size={15} />
      </div>
      <p className="mt-2.5 font-mono text-[16px] font-semibold text-mist-50">{value}</p>
      <p className="mt-0.5 text-[11px] text-mist-400">{label}</p>
    </div>
  )
}
