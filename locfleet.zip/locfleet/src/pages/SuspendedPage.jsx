import { ShieldAlert, Mail } from 'lucide-react'
import { BrandMark } from '../components/shared/Logo.jsx'

export default function SuspendedPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-ink-950 px-4">
      <div className="w-full max-w-sm text-center">
        <div className="mb-8 flex flex-col items-center gap-3">
          <BrandMark size={40} />
          <div className="leading-tight">
            <p className="font-display text-[17px] font-extrabold text-mist-50">
              Loc<span className="text-brand-400">Fleet</span>
            </p>
          </div>
        </div>

        <div className="surface-card p-6">
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-ruby-500/10 text-ruby-400">
            <ShieldAlert size={22} />
          </div>
          <h1 className="text-[15px] font-semibold text-mist-50">Acesso temporariamente suspenso</h1>
          <p className="mt-2 text-[13px] leading-relaxed text-mist-400">
            Sua conta está com o acesso pausado no momento. Isso costuma acontecer por pendência
            de pagamento. Entre em contato com o suporte para regularizar e voltar a usar o sistema.
          </p>

          <a
            href="mailto:suporte@locfleet.com.br"
            className="mt-5 inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg bg-brand-500 text-[13px] font-semibold text-ink-950 transition-colors hover:bg-brand-400"
          >
            <Mail size={15} /> Falar com o suporte
          </a>
        </div>
      </div>
    </div>
  )
}
