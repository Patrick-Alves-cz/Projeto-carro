import { useState, useEffect } from 'react'
import { Building2, Save, Download, Upload, DatabaseZap, ShieldCheck, FileText, HardDrive, FolderOpen } from 'lucide-react'
import { useData } from '../../contexts/DataContext.jsx'
import { useToast } from '../../contexts/ToastContext.jsx'
import PageHeader from '../../components/ui/PageHeader.jsx'
import Button from '../../components/ui/Button.jsx'
import { storageAdapter } from '../../services/storageAdapter'

const TABS = [
  { key: 'empresa', label: 'Empresa', icon: Building2 },
  { key: 'contrato', label: 'Modelo de Contrato', icon: FileText },
  { key: 'backup', label: 'Backup', icon: DatabaseZap },
]

export default function SettingsPage() {
  const { settings, updateSettings } = useData()
  const toast = useToast()
  const [tab, setTab] = useState('empresa')
  const [form, setForm] = useState(settings)
  const [clausesText, setClausesText] = useState((settings.contractClauses || []).join('\n\n'))
  const [saving, setSaving] = useState(false)
  const [dataPath, setDataPath] = useState(null)

  useEffect(() => {
    if (window.electronStore?.dataPath) {
      window.electronStore.dataPath().then(setDataPath)
    }
  }, [])

  function handleChange(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }))
  }

  async function handleSave() {
    setSaving(true)
    await updateSettings(form)
    setSaving(false)
    toast.success('Configurações salvas com sucesso')
  }

  async function handleSaveClauses() {
    setSaving(true)
    const clauses = clausesText
      .split(/\n\s*\n/)
      .map((c) => c.trim())
      .filter(Boolean)
    await updateSettings({ contractClauses: clauses })
    setSaving(false)
    toast.success('Modelo de contrato atualizado', { description: 'As próximas locações já usarão as novas cláusulas.' })
  }

  async function handleExportBackup() {
    const payload = await storageAdapter.exportAll()
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `backup-${slugify(settings.companyName || 'locfleet')}-${new Date().toISOString().slice(0, 10)}.json`
    a.click()
    URL.revokeObjectURL(url)
    toast.success('Backup exportado com sucesso')
  }

  function handleImportClick() {
    const input = document.createElement('input')
    input.type = 'file'
    input.accept = 'application/json'
    input.onchange = async (e) => {
      const file = e.target.files?.[0]
      if (!file) return
      try {
        const text = await file.text()
        const payload = JSON.parse(text)
        await storageAdapter.importAll(payload)
        toast.success('Backup restaurado com sucesso', { description: 'Recarregue o sistema para ver os dados atualizados.' })
      } catch {
        toast.error('Não foi possível ler o arquivo de backup')
      }
    }
    input.click()
  }

  return (
    <div>
      <PageHeader title="Configurações" subtitle="Dados oficiais da empresa, modelo de contrato e backup" />

      <div className="mb-5 flex items-center gap-1 border-b border-ink-700">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`relative flex items-center gap-1.5 px-4 py-2.5 text-[13px] font-medium transition-colors ${
              tab === t.key ? 'text-brand-400' : 'text-mist-400 hover:text-mist-100'
            }`}
          >
            <t.icon size={14} /> {t.label}
            {tab === t.key && <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-brand-500" />}
          </button>
        ))}
      </div>

      {tab === 'empresa' && (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="surface-card p-5 lg:col-span-2">
            <h3 className="label-eyebrow mb-1">Dados oficiais</h3>
            <p className="mb-4 text-[12px] text-mist-400">
              Usados automaticamente em contratos, relatórios, PDFs e cabeçalhos do sistema.
            </p>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Field label="Nome fantasia">
                <input value={form.companyName} onChange={(e) => handleChange('companyName', e.target.value)} className="input" />
              </Field>
              <Field label="Razão social">
                <input value={form.legalName} onChange={(e) => handleChange('legalName', e.target.value)} className="input" placeholder="RUFINO RENT CAR LTDA" />
              </Field>
              <Field label="CNPJ">
                <input value={form.cnpj} onChange={(e) => handleChange('cnpj', e.target.value)} className="input font-mono" placeholder="00.000.000/0000-00" />
              </Field>
              <Field label="Administrador">
                <input value={form.ownerName} onChange={(e) => handleChange('ownerName', e.target.value)} className="input" />
              </Field>
              <Field label="Telefone">
                <input value={form.phone} onChange={(e) => handleChange('phone', e.target.value)} className="input" placeholder="(66) 90000-0000" />
              </Field>
              <Field label="E-mail">
                <input value={form.email} onChange={(e) => handleChange('email', e.target.value)} className="input" placeholder="contato@rufinorentcar.com.br" />
              </Field>
              <Field label="Endereço">
                <input value={form.address} onChange={(e) => handleChange('address', e.target.value)} className="input" placeholder="Rua, número, bairro, cidade - UF" />
              </Field>
              <Field label="Cidade para contratos" hint="Usado em 'Local e data' no rodapé do contrato">
                <input value={form.contractCity} onChange={(e) => handleChange('contractCity', e.target.value)} className="input" placeholder="Rondonópolis - MT" />
              </Field>
            </div>
            <div className="mt-5">
              <Button icon={Save} loading={saving} onClick={handleSave}>Salvar alterações</Button>
            </div>
          </div>

          <div className="surface-card p-5">
            <h3 className="label-eyebrow mb-3">Pré-visualização do cabeçalho</h3>
            <div className="rounded-lg border border-ink-600 bg-ink-950 p-4">
              <p className="font-display text-[14px] font-bold text-mist-50">{form.companyName}</p>
              <p className="mt-1 text-[11px] text-mist-400">{form.legalName}</p>
              <p className="text-[11px] text-mist-400">CNPJ: {form.cnpj}</p>
              <div className="divider-brand my-2.5" />
              <p className="text-[11px] text-mist-400">Administrador: {form.ownerName}</p>
              {form.address && <p className="text-[11px] text-mist-400">{form.address}</p>}
            </div>
            <p className="mt-3 text-[11.5px] leading-relaxed text-mist-400">
              É assim que a empresa aparecerá no cabeçalho de contratos e relatórios exportados.
            </p>
          </div>
        </div>
      )}

      {tab === 'contrato' && (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="surface-card p-5 lg:col-span-2">
            <h3 className="label-eyebrow mb-1">Cláusulas do contrato</h3>
            <p className="mb-4 text-[12px] text-mist-400">
              Separe cada bloco (título de cláusula ou parágrafo) por uma linha em branco. Blocos que
              começam com "CLÁUSULA" viram títulos em destaque; os demais são exibidos como parágrafo,
              exatamente como digitados — a numeração (1.1, 3.9.1...) já faz parte do texto. Campos como{' '}
              <code className="rounded bg-ink-700 px-1 py-0.5 text-[11px]">{'{{CLIENTE_NOME}}'}</code> e{' '}
              <code className="rounded bg-ink-700 px-1 py-0.5 text-[11px]">{'{{VEICULO_PLACA}}'}</code>{' '}
              são preenchidos automaticamente ao gerar cada contrato.
            </p>
            <textarea
              value={clausesText}
              onChange={(e) => setClausesText(e.target.value)}
              rows={16}
              className="input h-auto resize-y py-3 font-mono text-[12.5px] leading-relaxed"
            />
            <div className="mt-5">
              <Button icon={Save} loading={saving} onClick={handleSaveClauses}>Salvar cláusulas</Button>
            </div>
          </div>

          <div className="surface-card p-5">
            <h3 className="label-eyebrow mb-3">Como funciona</h3>
            <ul className="space-y-2.5 text-[12.5px] leading-relaxed text-mist-400">
              <li>• Blocos iniciados por "CLÁUSULA" viram títulos; os demais são parágrafos do contrato.</li>
              <li>• Tokens entre chaves duplas, como {'{{VALOR_TOTAL}}'}, são substituídos pelos dados reais da locação.</li>
              <li>• Contratos já emitidos não são alterados — cada um guarda sua própria cópia no momento da emissão.</li>
              <li>• Novos contratos passam a usar a versão mais recente automaticamente.</li>
            </ul>
          </div>
        </div>
      )}

      {tab === 'backup' && (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="surface-card p-5 lg:col-span-2">
            <h3 className="label-eyebrow mb-4 flex items-center gap-1.5">
              <HardDrive size={13} /> Onde os dados estão salvos
            </h3>

            {storageAdapter.isElectron ? (
              <div className="mb-4 rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-3.5">
                <p className="flex items-center gap-2 text-[12.5px] font-semibold text-emerald-400">
                  <HardDrive size={14} /> Salvando em arquivo no computador ✓
                </p>
                {dataPath && (
                  <p className="mt-1.5 flex items-center gap-1.5 break-all font-mono text-[11px] text-mist-400">
                    <FolderOpen size={12} /> {dataPath}
                  </p>
                )}
                <p className="mt-2 text-[11.5px] leading-relaxed text-mist-300">
                  Os dados são salvos automaticamente nesse arquivo. Para fazer backup, basta
                  copiar esse arquivo para um pen drive ou e-mail.
                </p>
              </div>
            ) : (
              <div className="mb-4 rounded-lg border border-amber-500/20 bg-amber-500/5 p-3.5">
                <p className="flex items-center gap-2 text-[12.5px] font-semibold text-amber-400">
                  🌐 Modo navegador — dados no LocalStorage
                </p>
                <p className="mt-1.5 text-[11.5px] leading-relaxed text-mist-300">
                  Você está no modo de desenvolvimento (navegador). No programa instalado (.exe),
                  os dados são salvos em arquivo, de forma mais segura.
                </p>
              </div>
            )}

            <p className="mb-3 text-[12.5px] text-mist-400">
              Além do salvamento automático, faça backups manuais regularmente — especialmente antes de grandes atualizações.
            </p>
            <div className="flex flex-col gap-2.5 sm:flex-row">
              <Button variant="secondary" icon={Download} onClick={handleExportBackup}>Exportar backup (.json)</Button>
              <Button variant="secondary" icon={Upload} onClick={handleImportClick}>Restaurar backup</Button>
            </div>
          </div>
          <div className="surface-card p-5">
            <div className="flex items-start gap-2.5 rounded-lg bg-ink-800/60 p-3">
              <ShieldCheck size={16} className="mt-0.5 shrink-0 text-brand-400" />
              <p className="text-[11.5px] leading-relaxed text-mist-400">
                Arquitetura preparada para migração futura: login, banco de dados online e versão
                instalável (.exe), sem perda de dados.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function Field({ label, children, hint }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[12px] font-medium text-mist-300">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-[11px] text-mist-500">{hint}</span>}
    </label>
  )
}

/** slugify — turns a company name into a filesystem-safe slug for backup filenames. */
function slugify(text) {
  return text
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
}
