import { useState } from 'react'
import { Loader2, LogIn } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext.jsx'
import { BrandMark } from '../components/shared/Logo.jsx'

/**
 * LoginPage
 *
 * PARA APRENDER: por que não tem botão de "criar conta" aqui?
 *
 * Decisão de negócio, não limitação técnica: no seu modelo, o cliente só
 * ganha acesso DEPOIS de pagar, e é você quem cria o login dele (veja
 * "Como criar o login de um cliente novo" no README). Uma tela pública
 * de cadastro deixaria qualquer pessoa criar uma conta sozinha — o que
 * faz sentido pra produtos de auto-atendimento, mas não pro seu modelo
 * de venda direta. Por isso só existe "Entrar" aqui.
 */
export default function LoginPage() {
  const { signIn } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      await signIn(email, password)
    } catch (err) {
      setError(translateError(err.message))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-ink-950 px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center gap-3">
          <BrandMark size={40} />
          <div className="text-center leading-tight">
            <p className="font-display text-[17px] font-extrabold text-mist-50">
              Loc<span className="text-brand-400">Fleet</span>
            </p>
            <p className="font-display text-[9px] font-semibold tracking-[0.18em] text-mist-400">GESTÃO INTELIGENTE DE FROTAS</p>
          </div>
        </div>

        <div className="surface-card p-6">
          <h1 className="text-center text-[15px] font-semibold text-mist-50">Entrar no sistema</h1>
          <form onSubmit={handleSubmit} className="mt-5 space-y-3.5">
            <label className="block">
              <span className="mb-1.5 block text-[12px] font-medium text-mist-300">E-mail</span>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input"
                placeholder="voce@email.com"
                autoComplete="email"
              />
            </label>
            <label className="block">
              <span className="mb-1.5 block text-[12px] font-medium text-mist-300">Senha</span>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="input"
                placeholder="••••••••"
                autoComplete="current-password"
              />
            </label>

            {error && <p className="text-[12.5px] text-ruby-400">{error}</p>}

            <button
              type="submit"
              disabled={loading}
              className="flex h-10 w-full items-center justify-center gap-2 rounded-lg bg-brand-500 text-[13px] font-semibold text-ink-950 transition-colors hover:bg-brand-400 disabled:opacity-60"
            >
              {loading ? <Loader2 size={15} className="animate-spin" /> : <LogIn size={15} />}
              Entrar
            </button>
          </form>
        </div>

        <p className="mt-5 text-center text-[12px] text-mist-500">
          Acesso disponível apenas para clientes ativos. Para adquirir o sistema, entre em
          contato com o suporte.
        </p>
      </div>
    </div>
  )
}

function translateError(message) {
  const map = {
    'Invalid login credentials': 'E-mail ou senha incorretos.',
    'Email not confirmed': 'E-mail ainda não confirmado. Verifique a caixa de entrada.',
  }
  return map[message] || message
}
