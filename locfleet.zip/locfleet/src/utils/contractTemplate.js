/**
 * defaultContractTemplate.js
 *
 * Full legal rental-agreement template, based on the company's real
 * paper contract. Every {{TOKEN}} is replaced at generation time with
 * live data by fillContractTemplate() in contractExport.js — the
 * auto-fill logic itself never changes, only this text does.
 *
 * Entries starting with 'CLÁUSULA' render as section headings; every
 * other entry is a clause body and already carries its own legal
 * numbering (e.g. '3.9.1 ...') exactly as in the source document, so
 * clause references stay citable. Editable in Configurações > Modelo
 * de Contrato without touching code.
 */
export const DEFAULT_CONTRACT_CLAUSES = [
  'CONTRATO DE LOCAÇÃO DE VEÍCULO AUTOMOTOR',
  '{{LOCADORA_RAZAO_SOCIAL}}, pessoa jurídica de direito privado, inscrita no CNPJ sob o nº {{LOCADORA_CNPJ}}, com sede em {{LOCADORA_ENDERECO}}, também identificada comercialmente como {{LOCADORA_NOME_FANTASIA}}, neste ato representada por seu administrador {{LOCADORA_ADMINISTRADOR}}, doravante denominada LOCADORA.',
  '{{CLIENTE_NOME}}, portador(a) do RG nº {{CLIENTE_RG}}, inscrito(a) no CPF sob o nº {{CLIENTE_CPF}}, residente e domiciliado(a) em {{CLIENTE_ENDERECO}}, doravante denominado(a) LOCATÁRIO, vêm, por meio deste instrumento, celebrar CONTRATO DE LOCAÇÃO DE VEÍCULO AUTOMOTOR, regido pelas cláusulas e condições a seguir dispostas.',

  'CLÁUSULA 1ª – DO OBJETO DO CONTRATO',
  '1.1 O objeto do presente contrato é o seguinte veículo automotor: MARCA/MODELO: {{VEICULO_MARCA_MODELO}}, COR: {{VEICULO_COR}}, ANO: {{VEICULO_ANO}}, PLACA: {{VEICULO_PLACA}}, RENAVAM: {{VEICULO_RENAVAM}}, com {{VEICULO_KM}} rodados até a presente data deste contrato.',
  '1.2 O automóvel, objeto deste contrato, será utilizado exclusivamente pelo LOCATÁRIO, não sendo permitido sub-rogar os direitos por ele obtidos através do presente contrato a terceiros, tampouco permitir que outra pessoa conduza o referido veículo sem a inequívoca e expressa autorização da LOCADORA, sob pena de rescisão contratual, multa de R$ 4.000,00 (quatro mil reais), bem como responsabilização total por qualquer dano em relação ao veículo, inclusive os provenientes de caso fortuito ou força maior.',

  'CLÁUSULA 2ª – DO HORÁRIO DO ALUGUEL E LOCAL DE COLETA E DEVOLUÇÃO DO VEÍCULO',
  '2.1 O veículo objeto do presente contrato permanecerá na posse do locatário por período integral, de segunda à domingo.',
  '2.2 O LOCATÁRIO deverá apresentar o veículo à LOCADORA 1 (uma) vez por semana para a realização de vistoria pela LOCADORA ou por pessoa por ela indicada, em data e endereço por esta designados.',
  '2.3 A não apresentação do veículo no prazo e local acima supracitados acarreta ao LOCATÁRIO multa de R$ 100,00 (cem reais) por dia de atraso além de rescisão contratual.',

  'CLÁUSULA 3ª – DAS OBRIGAÇÕES DA LOCADORA E DO LOCATÁRIO',
  '3.1 O veículo objeto do presente contrato será submetido à manutenção preventiva periódica realizada por profissional mecânico designado pela LOCADORA, nos termos a seguir ou em caso de necessidade atestada pelo mecânico da LOCADORA: óleo do motor (1 vez por mês); filtro de óleo do motor (1 vez a cada 2 meses); filtro de ar (1 vez a cada 2 meses); vela e cabo de vela (a cada 5 meses); bobina (a cada 5 meses); correia dentada/correia de comando (a cada 6 meses).',
  '3.2 A cada 10.000 (dez mil) km ou proporcional à quilometragem rodada, caso alguma das manutenções supracitadas seja necessária antes do período estipulado, deverá ser arcada de forma 100% pela LOCADORA.',
  '3.3 Os gastos decorrentes da manutenção periódica, bem como o valor pago pela mão de obra do profissional que realizará o serviço, serão arcados pela LOCADORA. As manutenções que não foram citadas na cláusula 3.1 também terão que ser arcadas 100% pela LOCADORA, exceto em caso de mau uso, hipótese em que serão arcadas 100% pelo LOCATÁRIO.',
  '3.4 No caso de quebra, defeito ou desgaste percebido em ocasião diversa da manutenção periódica, deverá o LOCATÁRIO informar a LOCADORA imediatamente, bem como apresentar o veículo a esta para reparos a serem realizados por profissional mecânico designado pela LOCADORA.',
  '3.5 Caso a bomba de combustível queime ou se danifique por falta de combustível ou negligência quando o carro estiver em posse do LOCATÁRIO, este deverá arcar com o valor integral da peça, mão de obra, reboque do carro e demais valores inerentes ao reparo.',
  '3.6 A LOCADORA obriga-se a manter Proteção Veicular contratada para o veículo objeto do presente contrato.',
  '3.7 É de responsabilidade da LOCADORA o pagamento do IPVA (Imposto sobre Veículo Automotor), bem como o pagamento do seguro contratado para o veículo objeto do presente contrato.',
  '3.8 É de responsabilidade do LOCATÁRIO o pagamento de quaisquer multas inerentes à utilização do veículo sofridas na vigência deste contrato, salvo na ocasião em que o automóvel se encontrar na posse da LOCADORA.',
  '3.9 O pagamento das multas pelo LOCATÁRIO deverá ser feito imediatamente após a constatação no sistema do DETRAN, sendo que a verificação das multas deverá ser feita semanalmente pelo LOCATÁRIO, informando à LOCADORA a existência das mesmas, independentemente de qualquer procedimento, seja transferência de pontos ou recurso.',
  '3.9.1 O LOCATÁRIO concorda que a LOCADORA irá indicá-lo como condutor/infrator responsável pelas infrações de trânsito apuradas durante a locação, nos termos do artigo 257, parágrafos 1º, 3º, 7º e 8º do Código de Trânsito Brasileiro. A partir da indicação, o LOCATÁRIO terá legitimidade para se defender perante o órgão autuador.',
  '3.9.2 Qualquer questionamento sobre eventual improcedência de multas de trânsito deverá ser feito pelo LOCATÁRIO exclusivamente perante o órgão autuador.',
  '3.9.3 Se o LOCATÁRIO optar por recorrer da autuação e o recurso for vitorioso, a LOCADORA lhe fornecerá cópia da guia de pagamento para que solicite ao órgão o reembolso.',
  '3.10 Na ocorrência da imposição de multas acima mencionadas, deverá o LOCATÁRIO, assim que a autuação da infração chegar à sede da LOCADORA, comparecer em data e local estipulado pela LOCADORA para a assinatura do ato de infração para fins de transferência dos pontos para a sua CNH, sob pena de pagar à LOCADORA a quantia de R$ 400,00 (quatrocentos reais) em caso de perda de prazo para a transferência dos pontos do real infrator.',
  '3.11 Caso o veículo seja rebocado por estacionamento irregular, o LOCATÁRIO deverá arcar com todos os custos necessários para a recuperação do carro junto ao respectivo depósito público. O LOCATÁRIO deverá arcar também com multa contratual de R$ 200,00 (duzentos reais) por dia em que o carro estiver no depósito, a título de lucro cessante.',
  '3.12 Caso o LOCATÁRIO estacione em local diferente do informado à LOCADORA conforme declaração assinada, o LOCATÁRIO deverá arcar com qualquer dano ou prejuízo pecuniário ao veículo, inclusive os inerentes a caso fortuito ou força maior.',
  '3.13 Fica vedado ao LOCATÁRIO o acionamento da proteção veicular do veículo objeto deste contrato sem a expressa permissão da LOCADORA, sob pena de multa de R$ 200,00 (duzentos reais), além da obrigação de arcar com eventuais reboques necessários, caso o seguro não mais disponibilize esse serviço devido ao limite de utilizações mensais.',
  '3.14 O LOCATÁRIO se responsabiliza por quaisquer acessórios do veículo que estiverem em sua posse, como, por exemplo, chave do carro, documento do carro, tapetes, triângulo, macaco, estepe e rádio do carro. Caso algum acessório seja perdido ou danificado, o LOCATÁRIO deverá arcar com todos os custos necessários à reposição.',
  '3.15 Fica vedado ao LOCATÁRIO sair do Estado com o veículo objeto deste contrato sem a autorização expressa e por escrito da LOCADORA, sob pena de multa de R$ 4.000,00 (quatro mil reais), além de responsabilização por quaisquer ocorrências com o carro, inclusive em caso fortuito e força maior.',
  '3.16 É vedado ao LOCATÁRIO efetuar qualquer reparo ou serviço no carro sem a expressa e prévia anuência da LOCADORA, sob pena de não ser reembolsado por tais serviços e ainda arcar com eventuais danos ao veículo.',
  '3.17 Em caso de roubo ou furto do carro, o LOCATÁRIO se compromete a avisar imediatamente a LOCADORA ou quem esta indicar, bem como a comparecer à delegacia de polícia mais próxima para registrar a ocorrência.',
  '3.18 O LOCATÁRIO se compromete a comparecer à sede da seguradora ou a outro local por ela especificado a fim de cumprir com o procedimento de indenização do veículo.',
  '3.19 Caso o LOCATÁRIO se envolva em sinistro estando sob ação de álcool ou entorpecentes, ou caso o condutor não realize o teste de embriaguez requerido pela autoridade, este deverá arcar com o valor da tabela FIPE do carro, caso a indenização do seguro seja negada, ou com todos os custos inerentes à recuperação do veículo junto ao depósito, em caso de reboque.',
  '3.20 Fica proibido fumar dentro do veículo, seja pelo LOCATÁRIO, seja por qualquer passageiro, sob pena de rescisão de contrato e multa de R$ 1.000,00 (mil reais).',
  '3.21 Fica proibido retirar qualquer adesivo que esteja no interior ou exterior do veículo, sob pena de multa de R$ 100,00 (cem reais) em caso de retirada.',

  'CLÁUSULA 4ª – DAS OBRIGAÇÕES DECORRENTES DE COLISÕES E AVARIAS DO VEÍCULO',
  '4.1 É de responsabilidade do LOCATÁRIO o pagamento do reboque, taxas e reparos ao veículo objeto do presente contrato, ou a veículo de terceiros, na ocorrência de acidentes e colisões sofridas na vigência do presente contrato quando não contemplados pela cobertura do seguro contratado, independentemente de dolo, culpa, negligência, imprudência ou imperícia do LOCATÁRIO.',
  '4.2 Na ocorrência de necessidade de pagamento de franquia do seguro, a quantia paga a título de franquia será de responsabilidade integral do LOCATÁRIO.',
  '4.3 Será de responsabilidade do LOCATÁRIO o pagamento de taxas e diárias para a liberação do veículo decorrentes de reboque realizado pelo Poder Público, nos casos supracitados.',
  '4.4 A responsabilidade determinada nos itens supracitados permanece estabelecida inclusive quando o LOCATÁRIO não se encontrar no interior do veículo objeto do presente contrato.',

  'CLÁUSULA 5ª – DO PAGAMENTO EM RAZÃO DA LOCAÇÃO DO VEÍCULO',
  '5.1 O LOCATÁRIO pagará à LOCADORA o valor de {{VALOR_DIARIA}} por diária de locação, pelo período de {{DATA_RETIRADA}} a {{DATA_DEVOLUCAO}}, totalizando {{QTD_DIAS}} diária(s) e valor total de {{VALOR_TOTAL}}, por meio de {{FORMA_PAGAMENTO}}.',
  '5.2 Em caso de prorrogação do período de locação, as diárias adicionais seguirão o mesmo valor estipulado no item 5.1, salvo acordo em contrário formalizado por escrito entre as partes.',
  '5.3 Caso o pagamento seja realizado com atraso em relação à data acordada, incidirá acréscimo de R$ 100,00 (cem reais) por dia de atraso, a título de multa moratória. Caso o atraso acumule o valor de R$ 300,00 (trezentos reais), configurar-se-á quebra de contrato, resultando na perda da QUANTIA CAUÇÃO e na devolução imediata do veículo.',
  '5.4 Fica o LOCATÁRIO obrigado a encaminhar o comprovante de pagamento à LOCADORA em até 24 (vinte e quatro) horas após a efetivação de cada pagamento, sob pena de incidência da multa por atraso prevista no item 5.3, independentemente de comprovação posterior do pagamento.',

  'CLÁUSULA 6ª – DA QUANTIA CAUÇÃO',
  '6.1 Estabelecem as partes a QUANTIA CAUÇÃO em valor total de R$ 1.500,00 (mil e quinhentos reais), a ser paga em {{DATA_RETIRADA}}.',
  '6.2 Ao término da vigência do presente contrato, caberá à LOCADORA restituir a integralidade da QUANTIA CAUÇÃO ao LOCATÁRIO no prazo de 30 (trinta) dias úteis a contar da devolução do veículo por parte do LOCATÁRIO, conforme as seguintes condições: (i) devolução do automóvel em perfeito estado, em condição equivalente à observada no último checklist de vistoria e após vistoria feita por mecânico da LOCADORA; (ii) inexistência de aluguéis, multas de trânsito ou multas por descumprimento contratual pendentes por parte do LOCATÁRIO; (iii) realização da manutenção necessária do veículo, caso haja necessidade; (iv) dedução de quaisquer outros débitos pendentes.',
  '6.3 Na hipótese de não serem observadas as condições acima dispostas, poderá a LOCADORA utilizar-se da QUANTIA CAUÇÃO para adimplir eventuais débitos ou reparar danos causados ao automóvel que não decorram do desgaste natural e da utilização adequada do bem, hipótese na qual será de direito do LOCATÁRIO apenas a quantia remanescente, se houver.',
  '6.4 Os gastos com combustível do veículo deverão ser arcados integralmente pelo LOCATÁRIO, devendo este sempre entregar o veículo com a mesma quantidade de combustível nele contida quando de sua entrega pela LOCADORA. Caso o LOCATÁRIO não entregue o carro abastecido, será cobrado o valor de R$ 7,00 (sete reais) por litro faltante, debitado da QUANTIA CAUÇÃO.',
  '6.5 Qualquer valor inerente a cobrança por pedágio ou estacionamento do veículo durante a posse do LOCATÁRIO deverá por este ser arcado. Caso a LOCADORA seja cobrada por qualquer valor dessa natureza, o LOCATÁRIO deverá reembolsá-la imediatamente.',
  '6.6 Caso o carro seja devolvido sujo, será cobrada a lavagem simples ou especial, dependendo do seu estado. Na hipótese de lavagem especial, será cobrada também 1 (uma) diária de locação, ou quantas forem necessárias até a disponibilização do carro, limitadas a 10 (dez) diárias do carro alugado.',
  '6.7 Quando o documento do carro e o documento do GNV (quando houver) não forem devolvidos, será cobrado o reembolso das despesas para obtenção de 2ª via de ambos e, diante da impossibilidade de o carro ser alugado, também será cobrada indenização de 70% (setenta por cento) sobre o valor de 3 (três) diárias.',

  'CLÁUSULA 7ª – DA VIGÊNCIA E RESCISÃO',
  '7.1 O presente contrato terá vigência de {{DATA_RETIRADA}} a {{DATA_DEVOLUCAO}}, podendo ser prorrogado mediante acordo entre as partes, salvo manifestação de qualquer das partes em contrário, motivada por resilição ou descumprimento contratual ocasionado pela parte contrária.',
  '7.2 É assegurada à LOCADORA a rescisão do presente contrato a qualquer tempo, bastando, para tanto, dar ciência à outra parte acerca da rescisão, cabendo ao LOCATÁRIO a devolução do veículo à LOCADORA, em local por esta designado, imediatamente a contar do momento em que tiver ciência da resilição, quando esta for realizada pela LOCADORA.',
  '7.3 Até o término da vigência do contrato, o LOCATÁRIO não poderá rescindi-lo unilateralmente, salvo mediante o pagamento de multa no valor de R$ 1.500,00 (mil e quinhentos reais), no ato da devolução do veículo, e mediante aviso prévio de 24 (vinte e quatro) horas à LOCADORA.',
  '7.4 O contrato será considerado automaticamente rescindido pela LOCADORA, independentemente de qualquer notificação, providenciando esta, sem mais formalidades, a retomada do carro, sem que isso enseje ao LOCATÁRIO qualquer direito de retenção, indenização ou devolução da QUANTIA CAUÇÃO, nas seguintes hipóteses:',
  '7.4.1 O carro não for devolvido na data, hora e local previamente ajustados.',
  '7.4.2 Ocorrer qualquer acidente ou dano envolvendo o carro alugado, causado dolosa ou culposamente pelo LOCATÁRIO.',
  '7.4.3 Ocorrer uso inadequado do carro.',
  '7.4.4 Ocorrer apreensão do carro alugado por autoridades competentes.',
  '7.4.5 O LOCATÁRIO não quitar seus débitos nos respectivos vencimentos.',
  '7.4.6 Caso o LOCATÁRIO acumule uma dívida no valor máximo de R$ 300,00 (trezentos reais) e não a quite no prazo de 48 (quarenta e oito) horas, o contrato ficará automaticamente rescindido e o carro deverá ser entregue imediatamente em local determinado pela LOCADORA, sob pena de multa de R$ 200,00 (duzentos reais) por dia, salvo acordo em contrário entre as partes.',
  '7.4.7 O não cumprimento, pelo LOCATÁRIO, do dever de informar à LOCADORA qualquer mudança de endereço residencial também é causa de rescisão automática do contrato.',
  '7.5 Fica desde já pactuada a total inexistência de vínculo trabalhista entre as partes do presente contrato, sendo indevida toda e qualquer incidência de obrigações previdenciárias e encargos sociais, não havendo entre as partes qualquer tipo de subordinação e controle típicos de relações de emprego.',

  'CLÁUSULA 8ª – DO FORO',
  '8.1 Fica eleito o foro da Comarca de Cuiabá/MT para dirimir quaisquer dúvidas oriundas deste contrato, renunciando as partes a qualquer outro, por mais privilegiado que seja.',

  'CLÁUSULA 9ª – DA DEVOLUÇÃO DO VEÍCULO APÓS O TÉRMINO DO CONTRATO',
  '9.1 Após o término do contrato, o veículo deve ser devolvido imediatamente no local indicado pela LOCADORA, sob pena de multa de R$ 500,00 (quinhentos reais) por dia de atraso.',
  '9.2 Fica desde já esclarecido que a não devolução imediata do veículo pelo LOCATÁRIO à LOCADORA configura o crime de apropriação indébita, conforme artigo 168 do Código Penal Brasileiro, com pena de reclusão de um a quatro anos e multa.',

  'CLÁUSULA 10ª – DA DISPONIBILIZAÇÃO DE CARRO RESERVA',
  '10.1 A LOCADORA não é obrigada a disponibilizar carro reserva e não se responsabiliza caso o LOCATÁRIO fique impossibilitado de dirigir devido à indisponibilidade do veículo.',

  'CLÁUSULA 11ª – DAS NOTIFICAÇÕES',
  '11.1 Quaisquer notificações e comunicações enviadas sob este contrato devem ser feitas por escrito, por e-mail, WhatsApp ou correspondência com aviso de recebimento, aos endereços constantes do preâmbulo. Em caso de alteração de endereço, ficam as partes obrigadas a informar a outra parte.',
  '11.2 E, por estarem assim justas e contratadas, as partes firmam o presente instrumento em 2 (duas) vias de igual teor e forma, para que produza seus efeitos legais, após terem lido e compreendido claramente o seu conteúdo.',
]

/** isClauseHeading — heading entries render bold with extra spacing above; everything else is a normal clause paragraph. */
export function isClauseHeading(text) {
  return /^CLÁUSULA/i.test(text.trim()) || text.trim() === 'CONTRATO DE LOCAÇÃO DE VEÍCULO AUTOMOTOR'
}

/** isDocumentTitle — the very first line gets its own larger, centered treatment. */
export function isDocumentTitle(text) {
  return text.trim() === 'CONTRATO DE LOCAÇÃO DE VEÍCULO AUTOMOTOR'
}

/**
 * buildTemplateContext — flattens a contract snapshot (company, client,
 * vehicle, rental) into the {{TOKEN}} -> value map used to fill the
 * template. This is the single place that maps system data to contract
 * text, so the auto-fill behavior stays centralized and easy to extend.
 */
export function buildTemplateContext({ company, client, vehicle, rental }, helpers) {
  const { formatCurrency, formatDate, formatMileage, labelForPayment } = helpers

  return {
    LOCADORA_RAZAO_SOCIAL: company.legalName || company.name,
    LOCADORA_CNPJ: company.cnpj || '—',
    LOCADORA_NOME_FANTASIA: company.name,
    LOCADORA_ADMINISTRADOR: company.ownerName || '—',
    LOCADORA_ENDERECO: company.address || 'endereço não informado',
    CLIENTE_NOME: client.name,
    CLIENTE_RG: client.rg || '—',
    CLIENTE_CPF: client.cpf || '—',
    CLIENTE_ENDERECO: client.address || '—',
    VEICULO_MARCA_MODELO: `${vehicle.brand} ${vehicle.model}${vehicle.version ? ' ' + vehicle.version : ''}`,
    VEICULO_COR: vehicle.color || '—',
    VEICULO_ANO: vehicle.year || '—',
    VEICULO_PLACA: vehicle.plate || '—',
    VEICULO_RENAVAM: vehicle.renavam || '—',
    VEICULO_KM: vehicle.mileage ? formatMileage(vehicle.mileage) : '—',
    VALOR_DIARIA: formatCurrency(rental.dailyRate),
    QTD_DIAS: String(rental.days),
    VALOR_TOTAL: formatCurrency(rental.totalValue),
    DATA_RETIRADA: formatDate(rental.pickupDate),
    DATA_DEVOLUCAO: formatDate(rental.returnDate),
    FORMA_PAGAMENTO: labelForPayment(rental.paymentMethod),
  }
}

/** fillTemplate — replaces every {{TOKEN}} in a clause with its value from the context map. */
export function fillTemplate(text, context) {
  return text.replace(/\{\{(\w+)\}\}/g, (match, token) => context[token] ?? match)
}
