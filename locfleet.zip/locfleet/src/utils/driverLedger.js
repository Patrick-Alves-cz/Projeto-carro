import { eachDayOfInterval, isSameDay, isAfter, startOfDay, parseISO, format } from 'date-fns'
import { sum } from './calculations'

/**
 * dailyStatus — compares what was paid on a given day against the daily
 * rate to derive one of three states.
 */
export function dailyStatus(paidAmount, dailyRate) {
  if (paidAmount <= 0) return 'pendente'
  if (paidAmount >= dailyRate) return 'pago'
  return 'parcial'
}

/**
 * buildDailyLedger — expands the account's daily rate across every day
 * from its start date through today (or a custom end date), matching
 * each day against payments recorded for that date.
 */
export function buildDailyLedger(account, payments, endDate = new Date()) {
  if (!account?.startDate) return []
  const start = startOfDay(parseISO(account.startDate))
  const end = startOfDay(endDate)
  if (isAfter(start, end)) return []

  const days = eachDayOfInterval({ start, end })
  const paymentsByDay = new Map()
  payments.forEach((p) => {
    const key = format(parseISO(p.date), 'yyyy-MM-dd')
    paymentsByDay.set(key, (paymentsByDay.get(key) || 0) + Number(p.amount || 0))
  })

  return days.map((day) => {
    const key = format(day, 'yyyy-MM-dd')
    const paid = paymentsByDay.get(key) || 0
    return {
      date: day,
      key,
      due: account.dailyRate,
      paid,
      status: dailyStatus(paid, account.dailyRate),
    }
  })
}

/**
 * accountSummary — the headline numbers shown at the top of the driver's
 * financial page: balance, totals, days late, last payment.
 */
export function accountSummary(account, payments, endDate = new Date()) {
  const ledger = buildDailyLedger(account, payments, endDate)
  const totalDue = ledger.length * (account?.dailyRate || 0)
  const totalPaid = sum(payments, (p) => p.amount)
  const balanceDue = Math.max(0, totalDue - totalPaid)
  const daysLate = ledger.filter((d) => d.status !== 'pago' && !isSameDay(d.date, endDate)).length
  const sortedPayments = [...payments].sort((a, b) => new Date(b.date) - new Date(a.date))
  const lastPayment = sortedPayments[0] ?? null

  return {
    totalDue,
    totalPaid,
    balanceDue,
    daysLate,
    lastPayment,
    ledger,
  }
}
