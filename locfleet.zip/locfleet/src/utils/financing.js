import { addMonths, isBefore, parseISO } from 'date-fns'

export const FINANCING_STATUSES = [
  { value: 'quitado', label: 'Quitado' },
  { value: 'financiado', label: 'Financiado' },
  { value: 'consorcio', label: 'Consórcio' },
]

/**
 * generateInstallments — builds the full installment table from the
 * financing terms, one entry per month starting at firstDueDate (or
 * respecting dueDay if provided).
 */
export function generateInstallments({ totalInstallments, installmentValue, firstDueDate, dueDay }) {
  const count = Number(totalInstallments) || 0
  const value = Number(installmentValue) || 0
  const base = firstDueDate ? parseISO(firstDueDate) : new Date()

  const installments = []
  for (let i = 0; i < count; i++) {
    const due = addMonths(base, i)
    if (dueDay) due.setDate(Number(dueDay))
    installments.push({
      number: i + 1,
      dueDate: due.toISOString(),
      value,
      status: 'pendente',
      paidDate: null,
    })
  }
  return installments
}

/** installmentDisplayStatus — 'pago' is authoritative; otherwise derives 'atrasado' vs 'pendente' from the due date. */
export function installmentDisplayStatus(installment, today = new Date()) {
  if (installment.status === 'pago') return 'pago'
  try {
    return isBefore(parseISO(installment.dueDate), today) ? 'atrasado' : 'pendente'
  } catch {
    return 'pendente'
  }
}

/**
 * financingSummary — headline numbers for the vehicle's financing card:
 * how many installments are paid, how much is left, % of the vehicle
 * already paid off (down payment + installments paid vs. total).
 */
export function financingSummary(vehicle) {
  const f = vehicle?.financing
  if (!f || !f.status || f.status === 'quitado') {
    return {
      status: 'quitado',
      hasInstallments: false,
      paidCount: 0,
      totalCount: 0,
      remainingCount: 0,
      remainingValue: 0,
      percentPaid: 100,
      nextDue: null,
      overdueCount: 0,
    }
  }

  const installments = f.installments || []
  const paid = installments.filter((i) => i.status === 'pago')
  const remaining = installments.filter((i) => i.status !== 'pago')
  const overdue = remaining.filter((i) => installmentDisplayStatus(i) === 'atrasado')

  const totalValue = installments.reduce((s, i) => s + i.value, 0) + (Number(f.downPayment) || 0)
  const paidValue = paid.reduce((s, i) => s + i.value, 0) + (Number(f.downPayment) || 0)
  const percentPaid = totalValue > 0 ? (paidValue / totalValue) * 100 : 0

  const nextDue = [...remaining].sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate))[0] ?? null

  return {
    status: f.status,
    hasInstallments: installments.length > 0,
    paidCount: paid.length,
    totalCount: installments.length,
    remainingCount: remaining.length,
    remainingValue: remaining.reduce((s, i) => s + i.value, 0),
    percentPaid,
    nextDue,
    overdueCount: overdue.length,
    bank: f.bank,
    contractNumber: f.contractNumber,
    downPayment: f.downPayment,
    financedAmount: f.financedAmount,
    interestRate: f.interestRate,
  }
}
