import { LOGO_MARK_PNG_BASE64 } from '../assets/logoMarkBase64'
import { formatDateTime } from './formatters'

const PAGE_WIDTH = 210 // A4 in mm
const MARGIN = 14

/**
 * drawLetterhead — draws the standard header used across every PDF the
 * system generates (contracts and reports): logo mark, trade name, legal
 * name and CNPJ. Returns the Y coordinate where content can start.
 */
export function drawLetterhead(doc, settings, { title, subtitle } = {}) {
  doc.addImage(LOGO_MARK_PNG_BASE64, 'PNG', MARGIN, 10, 12, 12)

  doc.setFont('helvetica', 'bold')
  doc.setFontSize(13)
  doc.setTextColor(20, 20, 20)
  doc.text(settings?.companyName || 'LocFleet', MARGIN + 16, 16)

  doc.setFont('helvetica', 'normal')
  doc.setFontSize(8.5)
  doc.setTextColor(110, 110, 110)
  const legalLine = [settings?.legalName, settings?.cnpj ? `CNPJ ${settings.cnpj}` : null].filter(Boolean).join('  ·  ')
  if (legalLine) doc.text(legalLine, MARGIN + 16, 21)

  if (title) {
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(11)
    doc.setTextColor(20, 20, 20)
    doc.text(title, PAGE_WIDTH - MARGIN, 16, { align: 'right' })
  }
  if (subtitle) {
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(8.5)
    doc.setTextColor(110, 110, 110)
    doc.text(subtitle, PAGE_WIDTH - MARGIN, 21, { align: 'right' })
  }

  doc.setDrawColor(43, 166, 181)
  doc.setLineWidth(0.6)
  doc.line(MARGIN, 27, PAGE_WIDTH - MARGIN, 27)

  return 35
}

/**
 * drawFooter — draws the standard footer (page numbers + issuance
 * timestamp + company name) on every page of the document. Call once
 * after all content has been added, looping through doc.getNumberOfPages().
 */
export function drawFooter(doc, settings) {
  const totalPages = doc.internal.getNumberOfPages()
  const pageHeight = doc.internal.pageSize.getHeight()

  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i)
    doc.setDrawColor(225, 225, 225)
    doc.setLineWidth(0.3)
    doc.line(MARGIN, pageHeight - 16, PAGE_WIDTH - MARGIN, pageHeight - 16)

    doc.setFont('helvetica', 'normal')
    doc.setFontSize(7.5)
    doc.setTextColor(140, 140, 140)
    doc.text(settings?.companyName || 'LocFleet', MARGIN, pageHeight - 11)
    doc.text(`Emitido em ${formatDateTime(new Date().toISOString())}`, PAGE_WIDTH / 2, pageHeight - 11, { align: 'center' })
    doc.text(`Página ${i} de ${totalPages}`, PAGE_WIDTH - MARGIN, pageHeight - 11, { align: 'right' })
  }
}

export const PDF_LAYOUT = { PAGE_WIDTH, MARGIN }
