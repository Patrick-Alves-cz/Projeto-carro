import jsPDF from 'jspdf'
import autoTable from 'jspdf-autotable'
import * as XLSX from 'xlsx'
import { formatCurrency } from './formatters'
import { drawLetterhead, drawFooter, PDF_LAYOUT } from './pdfLetterhead'

/**
 * exportReportToPDF — builds a branded PDF summary table with the
 * standard company letterhead and footer (page numbers, issuance date).
 * @param {{title: string, settings: object, columns: string[], rows: (string|number)[][]}} report
 */
export function exportReportToPDF(report) {
  const doc = new jsPDF()

  const startY = drawLetterhead(doc, report.settings, { title: report.title, subtitle: 'Relatório gerencial' })

  autoTable(doc, {
    startY,
    head: [report.columns],
    body: report.rows,
    styles: { fontSize: 9, cellPadding: 3 },
    headStyles: { fillColor: [20, 20, 20], textColor: [43, 166, 181] },
    alternateRowStyles: { fillColor: [246, 246, 246] },
    margin: { left: PDF_LAYOUT.MARGIN, right: PDF_LAYOUT.MARGIN },
  })

  drawFooter(doc, report.settings)
  doc.save(`${report.fileName || 'relatorio'}.pdf`)
}

/**
 * exportReportToExcel — builds a .xlsx workbook from tabular data.
 * @param {{title: string, columns: string[], rows: (string|number)[][], fileName: string}} report
 */
export function exportReportToExcel(report) {
  const worksheet = XLSX.utils.aoa_to_sheet([report.columns, ...report.rows])
  const workbook = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(workbook, worksheet, report.title.slice(0, 31))
  XLSX.writeFile(workbook, `${report.fileName || 'relatorio'}.xlsx`)
}

export function buildVehicleProfitabilityReport(vehicles, rentals, expenses, vehicleProfileFn) {
  const rows = vehicles.map((v) => {
    const profile = vehicleProfileFn(v, rentals, expenses)
    return [
      `${v.brand} ${v.model}`,
      v.plate,
      formatCurrency(profile.totalRevenue),
      formatCurrency(profile.totalExpenses),
      formatCurrency(profile.netProfit),
      `${profile.roi.toFixed(1)}%`,
      profile.rentalCount,
    ]
  })
  return {
    title: 'Relatório de Lucratividade por Veículo',
    fileName: 'lucratividade-por-veiculo',
    columns: ['Veículo', 'Placa', 'Receita', 'Despesa', 'Lucro líquido', 'ROI', 'Locações'],
    rows,
  }
}
