import jsPDF from 'jspdf'
import QRCode from 'qrcode'
import { drawLetterhead, drawFooter, PDF_LAYOUT } from './pdfLetterhead'
import { formatCurrency, formatDate, formatDateTime, formatMileage } from './formatters'
import { labelFor, PAYMENT_METHODS } from './constants'
import { buildTemplateContext, fillTemplate, isClauseHeading, isDocumentTitle } from './contractTemplate'

const { MARGIN, PAGE_WIDTH } = PDF_LAYOUT
const PAGE_BOTTOM = 273

/**
 * buildContractSnapshot — captures every piece of data the contract needs
 * at the moment of issuance, so the document remains accurate forever
 * even if the client, vehicle or company settings change later.
 */
export function buildContractSnapshot({ rental, client, vehicle, settings }) {
  return {
    rentalId: rental.id,
    company: {
      name: settings.companyName,
      legalName: settings.legalName,
      cnpj: settings.cnpj,
      ownerName: settings.ownerName,
      address: settings.address,
      phone: settings.phone,
      email: settings.email,
      contractCity: settings.contractCity || settings.address || '',
    },
    client: {
      name: client?.name || '',
      cpf: client?.cpf || '',
      rg: client?.rg || '',
      cnh: client?.cnh || '',
      cnhExpiry: client?.cnhExpiry || '',
      phone: client?.phone || '',
      whatsapp: client?.whatsapp || '',
      email: client?.email || '',
      address: client?.address || '',
    },
    vehicle: {
      brand: vehicle?.brand || '',
      model: vehicle?.model || '',
      version: vehicle?.version || '',
      year: vehicle?.year || '',
      color: vehicle?.color || '',
      plate: vehicle?.plate || '',
      renavam: vehicle?.renavam || '',
      mileage: vehicle?.mileage || null,
    },
    rental: {
      pickupDate: rental.pickupDate,
      returnDate: rental.returnDate,
      days: rental.days,
      dailyRate: rental.dailyRate,
      totalValue: rental.totalValue,
      paymentMethod: rental.paymentMethod,
      mileageOut: rental.mileageOut || null,
      mileageReturnExpected: rental.mileageReturnExpected || null,
      notes: rental.notes || '',
    },
  }
}

async function buildQrDataUrl(contractNumber) {
  try {
    return await QRCode.toDataURL(`LOCFLEET|${contractNumber}`, {
      margin: 0,
      width: 200,
      color: { dark: '#141414', light: '#00000000' },
    })
  } catch {
    return null
  }
}

/**
 * generateContractPDF — renders the full rental agreement as a jsPDF
 * document and returns the jsPDF instance (caller decides whether to
 * save, open in a new tab for printing, or attach to an email).
 *
 * The legal text itself (title, preamble, all clauses) comes from
 * contract.clauses — a snapshot of settings.contractClauses at the time
 * this contract was issued, with {{TOKENS}} filled in from the contract's
 * own data. Editing the template later (Configurações > Modelo de
 * Contrato) never changes contracts already issued.
 */
export async function generateContractPDF(contract) {
  const doc = new jsPDF()
  const { company, client, vehicle, rental, clauses = [], contractNumber, issuedAt } = contract

  let y = drawLetterhead(doc, company, {
    title: `Contrato Nº ${contractNumber}`,
    subtitle: `Emitido em ${formatDateTime(issuedAt)}`,
  })

  // Quadro-resumo — quick-reference strip before the legal text itself,
  // purely additive (the full clauses below remain the authoritative text).
  doc.setFillColor(247, 247, 245)
  doc.roundedRect(MARGIN, y, PAGE_WIDTH - MARGIN * 2, 16, 1.5, 1.5, 'F')
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(8)
  doc.setTextColor(80, 80, 80)
  doc.text('LOCATÁRIO', MARGIN + 4, y + 5.5)
  doc.text('VEÍCULO', MARGIN + 4, y + 11.5)
  doc.setFont('helvetica', 'normal')
  doc.setTextColor(30, 30, 30)
  doc.text(`${client.name}  ·  CPF ${client.cpf || '—'}`, MARGIN + 26, y + 5.5)
  doc.text(
    `${vehicle.brand} ${vehicle.model}  ·  Placa ${vehicle.plate || '—'}  ·  Período ${formatDate(rental.pickupDate)} a ${formatDate(rental.returnDate)}  ·  Total ${formatCurrency(rental.totalValue)}`,
    MARGIN + 26,
    y + 11.5
  )
  y += 22

  // ---- Full legal text (title, preamble, all clauses) ----
  const context = buildTemplateContext(
    { company, client, vehicle, rental },
    { formatCurrency, formatDate, formatMileage, labelForPayment: (m) => labelFor(PAYMENT_METHODS, m) }
  )
  const textWidth = PAGE_WIDTH - MARGIN * 2

  function ensureSpace(neededHeight) {
    if (y + neededHeight > PAGE_BOTTOM) {
      doc.addPage()
      y = 20
    }
  }

  clauses.forEach((rawClause) => {
    const filled = fillTemplate(rawClause, context)

    if (isDocumentTitle(filled)) {
      ensureSpace(10)
      doc.setFont('helvetica', 'bold')
      doc.setFontSize(12.5)
      doc.setTextColor(20, 20, 20)
      doc.text(filled, PAGE_WIDTH / 2, y, { align: 'center' })
      y += 9
      return
    }

    if (isClauseHeading(filled)) {
      const lines = doc.splitTextToSize(filled, textWidth)
      ensureSpace(lines.length * 4.6 + 7)
      y += 3
      doc.setFont('helvetica', 'bold')
      doc.setFontSize(9.5)
      doc.setTextColor(20, 20, 20)
      doc.text(lines, MARGIN, y)
      y += lines.length * 4.6 + 2.5
      return
    }

    doc.setFont('helvetica', 'normal')
    doc.setFontSize(8.5)
    const lines = doc.splitTextToSize(filled, textWidth)
    ensureSpace(lines.length * 4.1 + 2)
    doc.setTextColor(55, 55, 55)
    doc.text(lines, MARGIN, y, { align: 'justify', maxWidth: textWidth })
    y += lines.length * 4.1 + 2.2
  })

  if (rental.notes) {
    ensureSpace(10)
    doc.setFont('helvetica', 'italic')
    doc.setFontSize(8.5)
    doc.setTextColor(90, 90, 90)
    const noteLines = doc.splitTextToSize(`Observações adicionais: ${rental.notes}`, textWidth)
    doc.text(noteLines, MARGIN, y)
    y += noteLines.length * 4.1 + 4
  }

  // ---- Signatures ----
  ensureSpace(38)
  y += 10

  const city = company.contractCity || ''
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(9)
  doc.setTextColor(60, 60, 60)
  doc.text(`${city ? `${city}, ` : ''}${formatDate(issuedAt)}`, MARGIN, y)
  y += 18

  const sigWidth = (PAGE_WIDTH - MARGIN * 2 - 20) / 2
  doc.setDrawColor(140, 140, 140)
  doc.setLineWidth(0.3)
  doc.line(MARGIN, y, MARGIN + sigWidth, y)
  doc.line(MARGIN + sigWidth + 20, y, PAGE_WIDTH - MARGIN, y)

  doc.setFontSize(8.5)
  doc.text(`${company.name} (Locadora)`, MARGIN + sigWidth / 2, y + 5, { align: 'center' })
  doc.text(`${client.name} (Locatário)`, MARGIN + sigWidth + 20 + sigWidth / 2, y + 5, { align: 'center' })
  doc.setFontSize(7)
  doc.setTextColor(140, 140, 140)
  doc.text('Assinatura digital — em breve', MARGIN + sigWidth / 2, y + 9, { align: 'center' })
  doc.text('Assinatura digital — em breve', MARGIN + sigWidth + 20 + sigWidth / 2, y + 9, { align: 'center' })

  // QR code (authenticity placeholder) — bottom right of the last page
  const qr = await buildQrDataUrl(contractNumber)
  if (qr) {
    const qrSize = 20
    doc.addImage(qr, 'PNG', PAGE_WIDTH - MARGIN - qrSize, y - 6, qrSize, qrSize)
    doc.setFontSize(6.5)
    doc.setTextColor(150, 150, 150)
    doc.text('Verificação de autenticidade', PAGE_WIDTH - MARGIN - qrSize / 2, y - 8, { align: 'center' })
  }

  drawFooter(doc, company)

  return doc
}
