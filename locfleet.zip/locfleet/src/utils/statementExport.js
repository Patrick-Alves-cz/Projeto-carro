import jsPDF from 'jspdf'
import autoTable from 'jspdf-autotable'
import * as XLSX from 'xlsx'
import { drawLetterhead, drawFooter, PDF_LAYOUT } from './pdfLetterhead'
import { formatCurrency, formatDate } from './formatters'
import { labelFor, PAYMENT_METHODS } from './constants'

const STATUS_LABEL = { pago: 'Pago', parcial: 'Parcial', pendente: 'Não pago' }

/**
 * exportDriverStatementPDF — full account statement for a single driver:
 * summary block + day-by-day ledger + payment history, branded with the
 * company letterhead like every other document in the system.
 */
export function exportDriverStatementPDF({ settings, client, account, summary, payments }) {
  const doc = new jsPDF()
  let y = drawLetterhead(doc, settings, {
    title: 'Extrato Financeiro do Motorista',
    subtitle: client.name,
  })

  autoTable(doc, {
    startY: y,
    theme: 'plain',
    styles: { fontSize: 9, cellPadding: 1.2 },
    columnStyles: { 0: { fontStyle: 'bold', cellWidth: 40 } },
    body: [
      ['Cliente', client.name],
      ['CPF', client.cpf || '—'],
      ['Diária acordada', formatCurrency(account.dailyRate)],
      ['Início do acompanhamento', formatDate(account.startDate)],
    ],
    margin: { left: PDF_LAYOUT.MARGIN, right: PDF_LAYOUT.MARGIN },
  })
  y = doc.lastAutoTable.finalY + 4

  autoTable(doc, {
    startY: y,
    head: [['Total devido', 'Total pago', 'Saldo em aberto', 'Dias em atraso']],
    body: [[
      formatCurrency(summary.totalDue),
      formatCurrency(summary.totalPaid),
      formatCurrency(summary.balanceDue),
      String(summary.daysLate),
    ]],
    styles: { fontSize: 9, cellPadding: 3, halign: 'center' },
    headStyles: { fillColor: [20, 20, 20], textColor: [43, 166, 181] },
    margin: { left: PDF_LAYOUT.MARGIN, right: PDF_LAYOUT.MARGIN },
  })
  y = doc.lastAutoTable.finalY + 8

  doc.setFont('helvetica', 'bold')
  doc.setFontSize(10)
  doc.setTextColor(20, 20, 20)
  doc.text('HISTÓRICO DE PAGAMENTOS', PDF_LAYOUT.MARGIN, y)
  y += 3

  autoTable(doc, {
    startY: y,
    head: [['Data', 'Valor', 'Forma de pagamento', 'Observações']],
    body: payments.length
      ? payments.map((p) => [formatDate(p.date), formatCurrency(p.amount), labelFor(PAYMENT_METHODS, p.method), p.notes || '—'])
      : [['—', '—', '—', 'Nenhum pagamento registrado']],
    styles: { fontSize: 8.5, cellPadding: 2.5 },
    headStyles: { fillColor: [20, 20, 20], textColor: [43, 166, 181] },
    margin: { left: PDF_LAYOUT.MARGIN, right: PDF_LAYOUT.MARGIN },
  })
  y = doc.lastAutoTable.finalY + 8

  if (y > 250) {
    doc.addPage()
    y = 20
  }

  doc.setFont('helvetica', 'bold')
  doc.setFontSize(10)
  doc.setTextColor(20, 20, 20)
  doc.text('EXTRATO DIÁRIO', PDF_LAYOUT.MARGIN, y)
  y += 3

  autoTable(doc, {
    startY: y,
    head: [['Data', 'Devido', 'Pago', 'Status']],
    body: summary.ledger.map((d) => [formatDate(d.date.toISOString()), formatCurrency(d.due), formatCurrency(d.paid), STATUS_LABEL[d.status]]),
    styles: { fontSize: 8, cellPadding: 2 },
    headStyles: { fillColor: [20, 20, 20], textColor: [43, 166, 181] },
    margin: { left: PDF_LAYOUT.MARGIN, right: PDF_LAYOUT.MARGIN },
    didParseCell: (data) => {
      if (data.section === 'body' && data.column.index === 3) {
        const val = data.cell.raw
        if (val === 'Pago') data.cell.styles.textColor = [63, 167, 114]
        if (val === 'Parcial') data.cell.styles.textColor = [201, 138, 63]
        if (val === 'Não pago') data.cell.styles.textColor = [201, 82, 79]
      }
    },
  })

  drawFooter(doc, settings)
  doc.save(`extrato-${client.name.replace(/\s+/g, '-').toLowerCase()}.pdf`)
}

/**
 * exportDriverStatementExcel — same statement data as a .xlsx workbook
 * with two sheets (summary+payments, daily ledger), for finance teams
 * that prefer to work the numbers in a spreadsheet.
 */
export function exportDriverStatementExcel({ client, account, summary, payments }) {
  const summarySheet = XLSX.utils.aoa_to_sheet([
    ['Cliente', client.name],
    ['CPF', client.cpf || '—'],
    ['Diária acordada', account.dailyRate],
    ['Início do acompanhamento', formatDate(account.startDate)],
    [],
    ['Total devido', summary.totalDue],
    ['Total pago', summary.totalPaid],
    ['Saldo em aberto', summary.balanceDue],
    ['Dias em atraso', summary.daysLate],
    [],
    ['Data', 'Valor', 'Forma de pagamento', 'Observações'],
    ...payments.map((p) => [formatDate(p.date), p.amount, labelFor(PAYMENT_METHODS, p.method), p.notes || '']),
  ])

  const ledgerSheet = XLSX.utils.aoa_to_sheet([
    ['Data', 'Devido', 'Pago', 'Status'],
    ...summary.ledger.map((d) => [formatDate(d.date.toISOString()), d.due, d.paid, STATUS_LABEL[d.status]]),
  ])

  const workbook = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(workbook, summarySheet, 'Resumo e Pagamentos')
  XLSX.utils.book_append_sheet(workbook, ledgerSheet, 'Extrato Diário')
  XLSX.writeFile(workbook, `extrato-${client.name.replace(/\s+/g, '-').toLowerCase()}.xlsx`)
}
