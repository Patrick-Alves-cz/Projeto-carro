import { useMemo, useState } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import {
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  isAfter,
  format,
  addMonths,
  subMonths,
} from 'date-fns'
import { ptBR } from 'date-fns/locale'
import clsx from 'clsx'
import { formatCurrency } from '../../utils/formatters'

const STATUS_DOT = {
  pago: 'bg-emerald-400',
  parcial: 'bg-amber-400',
  pendente: 'bg-ruby-400',
}

const WEEKDAYS = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S']

export default function PaymentCalendar({ ledger, accountStart, onSelectDay }) {
  const [cursor, setCursor] = useState(new Date())
  const today = new Date()

  const ledgerByKey = useMemo(() => {
    const map = new Map()
    ledger.forEach((d) => map.set(d.key, d))
    return map
  }, [ledger])

  const days = useMemo(() => {
    const start = startOfWeek(startOfMonth(cursor), { locale: ptBR })
    const end = endOfWeek(endOfMonth(cursor), { locale: ptBR })
    return eachDayOfInterval({ start, end })
  }, [cursor])

  const start = accountStart ? new Date(accountStart) : null

  return (
    <div>
      <div className="mb-3 flex items-center justify-between">
        <button
          onClick={() => setCursor((c) => subMonths(c, 1))}
          className="rounded-lg p-1.5 text-mist-400 transition-colors hover:bg-ink-700 hover:text-mist-100"
        >
          <ChevronLeft size={16} />
        </button>
        <p className="text-[13px] font-semibold capitalize text-mist-100">{format(cursor, 'MMMM yyyy', { locale: ptBR })}</p>
        <button
          onClick={() => setCursor((c) => addMonths(c, 1))}
          className="rounded-lg p-1.5 text-mist-400 transition-colors hover:bg-ink-700 hover:text-mist-100"
        >
          <ChevronRight size={16} />
        </button>
      </div>

      <div className="grid grid-cols-7 gap-1.5 text-center">
        {WEEKDAYS.map((w, i) => (
          <span key={i} className="text-[10px] font-semibold uppercase text-mist-500">{w}</span>
        ))}
        {days.map((day) => {
          const key = format(day, 'yyyy-MM-dd')
          const inMonth = isSameMonth(day, cursor)
          const entry = ledgerByKey.get(key)
          const beforeStart = start ? day < new Date(start.getFullYear(), start.getMonth(), start.getDate()) : false
          const future = isAfter(day, today) && !isSameDay(day, today)
          const clickable = inMonth && !beforeStart && !future

          return (
            <button
              key={key}
              disabled={!clickable}
              onClick={() => clickable && onSelectDay(day, entry)}
              title={entry ? `${format(day, 'dd/MM')} — pago ${formatCurrency(entry.paid)} de ${formatCurrency(entry.due)}` : undefined}
              className={clsx(
                'relative flex h-9 flex-col items-center justify-center rounded-lg text-[11.5px] transition-colors',
                inMonth ? 'text-mist-200' : 'text-mist-600',
                clickable ? 'hover:bg-ink-700 cursor-pointer' : 'cursor-default opacity-40',
                isSameDay(day, today) && 'ring-1 ring-brand-500/60'
              )}
            >
              {format(day, 'd')}
              {entry && (
                <span className={clsx('absolute bottom-1 h-1.5 w-1.5 rounded-full', STATUS_DOT[entry.status])} />
              )}
            </button>
          )
        })}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-4 border-t border-ink-700 pt-3 text-[11px] text-mist-400">
        <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-emerald-400" /> Pago</span>
        <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-amber-400" /> Parcial</span>
        <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-ruby-400" /> Não pago</span>
      </div>
    </div>
  )
}
