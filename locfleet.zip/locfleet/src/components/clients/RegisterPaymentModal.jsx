import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import Modal from '../ui/Modal.jsx'
import FormField from '../ui/FormField.jsx'
import Button from '../ui/Button.jsx'
import { PAYMENT_METHODS } from '../../utils/constants'

function toDateInput(date) {
  if (!date) return new Date().toISOString().slice(0, 10)
  return date instanceof Date ? date.toISOString().slice(0, 10) : date.slice(0, 10)
}

export default function RegisterPaymentModal({ open, onClose, defaultDate, defaultAmount, onSubmit }) {
  const [saving, setSaving] = useState(false)
  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    defaultValues: { date: toDateInput(defaultDate), amount: defaultAmount || '', method: 'dinheiro', notes: '' },
  })

  useEffect(() => {
    if (open) {
      reset({ date: toDateInput(defaultDate), amount: defaultAmount || '', method: 'dinheiro', notes: '' })
    }
  }, [open, defaultDate, defaultAmount, reset])

  async function submit(values) {
    setSaving(true)
    try {
      await onSubmit({ ...values, amount: Number(values.amount) || 0, date: new Date(values.date).toISOString() })
      onClose()
    } finally {
      setSaving(false)
    }
  }

  return (
    <Modal open={open} onClose={onClose} size="sm" title="Registrar pagamento" subtitle="Lance um pagamento na conta corrente do motorista">
      <form onSubmit={handleSubmit(submit)} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <FormField label="Data" required error={errors.date && 'Informe a data'}>
            <input type="date" className="input" {...register('date', { required: true })} />
          </FormField>
          <FormField label="Valor pago" required error={errors.amount && 'Informe o valor'}>
            <input type="number" step="0.01" className="input" placeholder="100.00" {...register('amount', { required: true })} />
          </FormField>
        </div>
        <FormField label="Forma de pagamento">
          <select className="input" {...register('method')}>
            {PAYMENT_METHODS.map((p) => (
              <option key={p.value} value={p.value}>{p.label}</option>
            ))}
          </select>
        </FormField>
        <FormField label="Observações">
          <textarea rows={2} className="input h-auto resize-none py-2.5" {...register('notes')} />
        </FormField>
        <div className="flex justify-end gap-2.5 border-t border-ink-700 pt-4">
          <Button type="button" variant="secondary" onClick={onClose}>Cancelar</Button>
          <Button type="submit" loading={saving}>Registrar pagamento</Button>
        </div>
      </form>
    </Modal>
  )
}
