import { useState } from 'react'
import { Landmark, CheckCircle2, ListPlus, Loader2 } from 'lucide-react'
import clsx from 'clsx'
import Badge from '../ui/Badge.jsx'
import Button from '../ui/Button.jsx'
import { useData } from '../../contexts/DataContext.jsx'
import { useToast } from '../../contexts/ToastContext.jsx'
import { financingSummary, installmentDisplayStatus } from '../../utils/financing'
import { formatCurrency, formatDate } from '../../utils/formatters'

const STATUS_TONE = { pago: 'emerald', pendente: 'azure', atrasado: 'ruby' }
const STATUS_LABEL = { pago: 'Pago', pendente: 'Pendente', atrasado: 'Atrasado' }

export default function VehicleFinancingPanel({ vehicle }) {
  const { generateVehicleInstallments, markInstallmentPaid } = useData()
  const toast = useToast()
  const [generating, setGenerating] = useState(false)
  const [payingNumber, setPayingNumber] = useState(null)

  const financing = vehicle.financing
  if (!financing || !financing.status || financing.status === 'quitado') {
    return (
      <div className="surface-card p-5">
        <h3 className="label-eyebrow mb-3 flex items-center gap-1.5"><Landmark size={13} /> Situação financeira</h3>
        <p className="text-[12.5px] text-mist-400">
          Veículo quitado — comprado por {formatCurrency(vehicle.purchaseValue)} em {formatDate(vehicle.purchaseDate)}.
        </p>
      </div>
    )
  }

  const summary = financingSummary(vehicle)

  async function handleGenerate() {
    setGenerating(true)
    try {
      await generateVehicleInstallments(vehicle.id, {
        totalInstallments: financing.totalInstallments,
        installmentValue: financing.installmentValue,
        firstDueDate: financing.firstDueDate,
        dueDay: financing.dueDay,
        downPayment: financing.downPayment,
        financedAmount: financing.financedAmount,
        bank: financing.bank,
        contractNumber: financing.contractNumber,
        interestRate: financing.interestRate,
        status: financing.status,
      })
      toast.success('Tabela de parcelas gerada com sucesso')
    } catch {
      toast.error('Não foi possível gerar as parcelas')
    } finally {
      setGenerating(false)
    }
  }

  async function handleMarkPaid(number) {
    setPayingNumber(number)
    try {
      await markInstallmentPaid(vehicle.id, number)
      toast.success(`Parcela ${number} marcada como paga`)
    } finally {
      setPayingNumber(null)
    }
  }

  return (
    <div className="surface-card p-5">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h3 className="label-eyebrow flex items-center gap-1.5">
          <Landmark size={13} /> {financing.status === 'consorcio' ? 'Consórcio' : 'Financiamento'}
        </h3>
        {!summary.hasInstallments && financing.totalInstallments > 0 && (
          <Button size="sm" variant="secondary" icon={generating ? Loader2 : ListPlus} loading={generating} onClick={handleGenerate}>
            Gerar tabela de parcelas
          </Button>
        )}
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <FinanceStat label="Parcelas pagas" value={`${summary.paidCount}/${summary.totalCount}`} />
        <FinanceStat label="Valor restante" value={formatCurrency(summary.remainingValue)} />
        <FinanceStat label="% quitado" value={`${summary.percentPaid.toFixed(0)}%`} tone="emerald" />
        <FinanceStat
          label="Próxima parcela"
          value={summary.nextDue ? formatDate(summary.nextDue.dueDate) : '—'}
          tone={summary.overdueCount > 0 ? 'ruby' : 'mist'}
        />
      </div>

      <dl className="mt-4 grid grid-cols-2 gap-x-6 gap-y-1.5 border-t border-ink-700 pt-4 text-[12px] sm:grid-cols-4">
        <Row label={financing.status === 'consorcio' ? 'Administradora' : 'Banco'} value={summary.bank} />
        <Row label="Contrato" value={summary.contractNumber} mono />
        <Row label="Entrada" value={formatCurrency(summary.downPayment)} />
        <Row label="Valor financiado" value={formatCurrency(summary.financedAmount)} />
      </dl>

      {summary.hasInstallments && (
        <div className="mt-4 max-h-72 overflow-y-auto rounded-lg border border-ink-700">
          <table className="w-full text-left text-[12.5px]">
            <thead className="sticky top-0 bg-ink-800">
              <tr className="text-[10.5px] uppercase tracking-wide text-mist-400">
                <th className="px-3 py-2 font-medium">Parcela</th>
                <th className="px-3 py-2 font-medium">Vencimento</th>
                <th className="px-3 py-2 font-medium">Valor</th>
                <th className="px-3 py-2 font-medium">Status</th>
                <th className="px-3 py-2 font-medium"></th>
              </tr>
            </thead>
            <tbody>
              {financing.installments.map((inst) => {
                const status = installmentDisplayStatus(inst)
                return (
                  <tr key={inst.number} className="border-t border-ink-800">
                    <td className="px-3 py-2 text-mist-100">{inst.number}/{financing.installments.length}</td>
                    <td className="px-3 py-2 text-mist-300">{formatDate(inst.dueDate)}</td>
                    <td className="px-3 py-2 font-mono text-mist-100">{formatCurrency(inst.value)}</td>
                    <td className="px-3 py-2">
                      <Badge tone={STATUS_TONE[status]}>{STATUS_LABEL[status]}</Badge>
                    </td>
                    <td className="px-3 py-2 text-right">
                      {status !== 'pago' && (
                        <button
                          onClick={() => handleMarkPaid(inst.number)}
                          disabled={payingNumber === inst.number}
                          className={clsx(
                            'inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-medium text-emerald-400 transition-colors hover:bg-emerald-500/10',
                            payingNumber === inst.number && 'opacity-50'
                          )}
                        >
                          <CheckCircle2 size={12} /> Marcar como paga
                        </button>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

function FinanceStat({ label, value, tone = 'mist' }) {
  const toneClasses = {
    brand: 'text-brand-400', emerald: 'text-emerald-400', ruby: 'text-ruby-400', mist: 'text-mist-50',
  }
  return (
    <div className="rounded-lg bg-ink-800/60 p-3">
      <p className={clsx('font-mono text-[15px] font-semibold', toneClasses[tone])}>{value}</p>
      <p className="mt-0.5 text-[10.5px] text-mist-400">{label}</p>
    </div>
  )
}

function Row({ label, value, mono }) {
  return (
    <div>
      <dt className="text-mist-500">{label}</dt>
      <dd className={clsx('text-mist-200', mono && 'font-mono')}>{value || '—'}</dd>
    </div>
  )
}
