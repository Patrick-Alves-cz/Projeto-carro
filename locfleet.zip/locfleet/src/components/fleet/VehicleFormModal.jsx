import { useEffect, useRef, useState } from 'react'
import { useForm } from 'react-hook-form'
import { Camera, Car, Loader2, Landmark } from 'lucide-react'
import clsx from 'clsx'
import Modal from '../ui/Modal.jsx'
import FormField from '../ui/FormField.jsx'
import Button from '../ui/Button.jsx'
import { VEHICLE_CATEGORIES, VEHICLE_STATUSES } from '../../utils/constants'
import { FINANCING_STATUSES } from '../../utils/financing'
import { formatPlate } from '../../utils/formatters'

const EMPTY_VALUES = {
  photo: '',
  brand: '',
  model: '',
  version: '',
  year: new Date().getFullYear(),
  color: '',
  plate: '',
  renavam: '',
  chassis: '',
  purchaseValue: '',
  purchaseDate: '',
  mileage: 0,
  category: 'hatch',
  status: 'disponivel',
  insuranceExpiry: '',
  licensingExpiry: '',
  notes: '',
  financing: {
    status: 'quitado',
    downPayment: '',
    financedAmount: '',
    totalInstallments: '',
    installmentValue: '',
    bank: '',
    contractNumber: '',
    firstDueDate: '',
    dueDay: '',
    interestRate: '',
  },
}

function toDateInput(iso) {
  if (!iso) return ''
  return iso.slice(0, 10)
}

export default function VehicleFormModal({ open, onClose, vehicle, onSubmit }) {
  const isEditing = Boolean(vehicle)
  const fileInputRef = useRef(null)
  const [saving, setSaving] = useState(false)

  const {
    register,
    handleSubmit,
    reset,
    watch,
    setValue,
    formState: { errors },
  } = useForm({ defaultValues: EMPTY_VALUES })

  useEffect(() => {
    if (open) {
      reset(
        vehicle
          ? {
              ...EMPTY_VALUES,
              ...vehicle,
              purchaseDate: toDateInput(vehicle.purchaseDate),
              insuranceExpiry: toDateInput(vehicle.insuranceExpiry),
              licensingExpiry: toDateInput(vehicle.licensingExpiry),
              financing: {
                ...EMPTY_VALUES.financing,
                ...(vehicle.financing || {}),
                firstDueDate: toDateInput(vehicle.financing?.firstDueDate),
              },
            }
          : EMPTY_VALUES
      )
    }
  }, [open, vehicle, reset])

  const financingStatus = watch('financing.status')

  const photo = watch('photo')

  function handlePhotoChange(e) {
    const file = e.target.files?.[0]
    if (!file) return
    if (file.size > 3 * 1024 * 1024) {
      alert('A imagem deve ter até 3MB.')
      return
    }
    const reader = new FileReader()
    reader.onload = () => setValue('photo', reader.result)
    reader.readAsDataURL(file)
  }

  async function submit(values) {
    setSaving(true)
    try {
      const financing = {
        status: values.financing.status,
        downPayment: Number(values.financing.downPayment) || 0,
        financedAmount: Number(values.financing.financedAmount) || 0,
        totalInstallments: Number(values.financing.totalInstallments) || 0,
        installmentValue: Number(values.financing.installmentValue) || 0,
        bank: values.financing.bank,
        contractNumber: values.financing.contractNumber,
        firstDueDate: values.financing.firstDueDate ? new Date(values.financing.firstDueDate).toISOString() : '',
        dueDay: values.financing.dueDay,
        interestRate: values.financing.interestRate,
        // The installment table itself is only ever generated/updated from
        // the vehicle detail page — this form never overwrites it, so
        // payment history already recorded is always preserved.
        installments: vehicle?.financing?.installments || [],
      }

      await onSubmit({
        ...values,
        year: Number(values.year),
        purchaseValue: Number(values.purchaseValue) || 0,
        mileage: Number(values.mileage) || 0,
        plate: formatPlate(values.plate),
        purchaseDate: values.purchaseDate ? new Date(values.purchaseDate).toISOString() : '',
        insuranceExpiry: values.insuranceExpiry ? new Date(values.insuranceExpiry).toISOString() : '',
        licensingExpiry: values.licensingExpiry ? new Date(values.licensingExpiry).toISOString() : '',
        financing,
      })
      onClose()
    } finally {
      setSaving(false)
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      size="lg"
      title={isEditing ? 'Editar veículo' : 'Novo veículo'}
      subtitle={isEditing ? `${vehicle.brand} ${vehicle.model} · ${vehicle.plate}` : 'Cadastre um veículo na frota'}
    >
      <form onSubmit={handleSubmit(submit)} className="space-y-5">
        <div className="flex items-center gap-4">
          <div className="flex h-20 w-28 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-ink-800">
            {photo ? <img src={photo} alt="" className="h-full w-full object-cover" /> : <Car size={24} className="text-mist-500" />}
          </div>
          <div>
            <input ref={fileInputRef} type="file" accept="image/*" onChange={handlePhotoChange} className="hidden" />
            <Button type="button" variant="secondary" size="sm" icon={Camera} onClick={() => fileInputRef.current?.click()}>
              {photo ? 'Trocar foto' : 'Adicionar foto'}
            </Button>
            <p className="mt-1.5 text-[11px] text-mist-400">JPG ou PNG, até 3MB</p>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <FormField label="Marca" required error={errors.brand && 'Informe a marca'}>
            <input className="input" placeholder="Chevrolet" {...register('brand', { required: true })} />
          </FormField>
          <FormField label="Modelo" required error={errors.model && 'Informe o modelo'}>
            <input className="input" placeholder="Onix" {...register('model', { required: true })} />
          </FormField>
          <FormField label="Versão">
            <input className="input" placeholder="LT 1.0 Turbo" {...register('version')} />
          </FormField>
          <FormField label="Ano" required error={errors.year && 'Informe o ano'}>
            <input type="number" className="input" {...register('year', { required: true })} />
          </FormField>
          <FormField label="Cor">
            <input className="input" placeholder="Branco" {...register('color')} />
          </FormField>
          <FormField label="Placa" required error={errors.plate && 'Informe a placa'}>
            <input className="input font-mono uppercase" placeholder="ABC1D23" maxLength={7} {...register('plate', { required: true })} />
          </FormField>
          <FormField label="RENAVAM">
            <input className="input font-mono" {...register('renavam')} />
          </FormField>
          <FormField label="Chassi">
            <input className="input font-mono" {...register('chassis')} />
          </FormField>
          <FormField label="Categoria" required>
            <select className="input" {...register('category')}>
              {VEHICLE_CATEGORIES.map((c) => (
                <option key={c.value} value={c.value}>{c.label}</option>
              ))}
            </select>
          </FormField>
          <FormField label="Status" required>
            <select className="input" {...register('status')}>
              {VEHICLE_STATUSES.map((s) => (
                <option key={s.value} value={s.value}>{s.label}</option>
              ))}
            </select>
          </FormField>
          <FormField label="Quilometragem">
            <input type="number" className="input" {...register('mileage')} />
          </FormField>
          <FormField label="Valor de compra">
            <input type="number" step="0.01" className="input" {...register('purchaseValue')} />
          </FormField>
          <FormField label="Data da compra">
            <input type="date" className="input" {...register('purchaseDate')} />
          </FormField>
          <FormField label="Seguro vence em">
            <input type="date" className="input" {...register('insuranceExpiry')} />
          </FormField>
          <FormField label="IPVA/Licenciamento vence em" className="sm:col-span-2">
            <input type="date" className="input" {...register('licensingExpiry')} />
          </FormField>
        </div>

        <FormField label="Observações">
          <textarea rows={3} className="input h-auto resize-none py-2.5" {...register('notes')} />
        </FormField>

        <div className="rounded-xl border border-ink-700 p-4">
          <p className="label-eyebrow mb-3 flex items-center gap-1.5"><Landmark size={13} /> Situação financeira</p>

          <div className="mb-4 flex gap-2">
            {FINANCING_STATUSES.map((s) => (
              <label
                key={s.value}
                className={clsx(
                  'flex-1 cursor-pointer rounded-lg border px-3 py-2 text-center text-[12.5px] font-medium transition-colors',
                  financingStatus === s.value
                    ? 'border-brand-500/50 bg-brand-500/10 text-brand-400'
                    : 'border-ink-600 text-mist-300 hover:bg-ink-800'
                )}
              >
                <input type="radio" value={s.value} className="hidden" {...register('financing.status')} />
                {s.label}
              </label>
            ))}
          </div>

          {financingStatus === 'quitado' && (
            <p className="text-[12px] text-mist-400">
              Veículo quitado — o valor de compra e a data da compra informados acima já são suficientes.
            </p>
          )}

          {(financingStatus === 'financiado' || financingStatus === 'consorcio') && (
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <FormField label="Valor de entrada">
                <input type="number" step="0.01" className="input" {...register('financing.downPayment')} />
              </FormField>
              <FormField label="Valor financiado">
                <input type="number" step="0.01" className="input" {...register('financing.financedAmount')} />
              </FormField>
              <FormField label="Quantidade total de parcelas">
                <input type="number" className="input" {...register('financing.totalInstallments')} />
              </FormField>
              <FormField label="Valor da parcela">
                <input type="number" step="0.01" className="input" {...register('financing.installmentValue')} />
              </FormField>
              <FormField label={financingStatus === 'consorcio' ? 'Administradora' : 'Banco'}>
                <input className="input" {...register('financing.bank')} />
              </FormField>
              <FormField label="Número do contrato">
                <input className="input font-mono" {...register('financing.contractNumber')} />
              </FormField>
              <FormField label="Data da 1ª parcela">
                <input type="date" className="input" {...register('financing.firstDueDate')} />
              </FormField>
              <FormField label="Dia do vencimento">
                <input type="number" min="1" max="31" className="input" {...register('financing.dueDay')} />
              </FormField>
              <FormField label="Taxa de juros (opcional)" hint="% ao mês">
                <input type="number" step="0.01" className="input" {...register('financing.interestRate')} />
              </FormField>
              <div className="flex items-end sm:col-span-2">
                <p className="text-[11.5px] leading-relaxed text-mist-400">
                  Após salvar, gere a tabela de parcelas na página do veículo. Parcelas já geradas e
                  pagamentos registrados não são afetados ao editar estes dados.
                </p>
              </div>
            </div>
          )}
        </div>

        <div className="flex justify-end gap-2.5 border-t border-ink-700 pt-4">
          <Button type="button" variant="secondary" onClick={onClose}>Cancelar</Button>
          <Button type="submit" loading={saving} icon={saving ? Loader2 : undefined}>
            {isEditing ? 'Salvar alterações' : 'Cadastrar veículo'}
          </Button>
        </div>
      </form>
    </Modal>
  )
}
