import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import ChartTooltip from '../dashboard/ChartTooltip'
import { formatCompactCurrency } from '../../utils/formatters'

export default function VehicleFinanceBars({ revenue, expenses, profit }) {
  const data = [
    { name: 'Receita', value: revenue, color: '#2BA6B5' },
    { name: 'Despesa', value: expenses, color: '#C9524F' },
    { name: 'Lucro', value: profit, color: profit >= 0 ? '#3FA772' : '#C9524F' },
  ]

  return (
    <ResponsiveContainer width="100%" height={220}>
      <BarChart data={data} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#212127" vertical={false} />
        <XAxis dataKey="name" tick={{ fill: '#75757F', fontSize: 11.5 }} axisLine={{ stroke: '#212127' }} tickLine={false} />
        <YAxis tick={{ fill: '#75757F', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={formatCompactCurrency} width={60} />
        <Tooltip content={<ChartTooltip />} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
        <Bar dataKey="value" name="Valor" radius={[6, 6, 0, 0]} maxBarSize={64}>
          {data.map((d) => (
            <Cell key={d.name} fill={d.color} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  )
}
