import { useMemo, useState } from 'react'
import { Eye, Download, Printer, Mail, FileCheck2, Loader2 } from 'lucide-react'
import Modal from '../ui/Modal.jsx'
import Button from '../ui/Button.jsx'
import Badge from '../ui/Badge.jsx'
import { useToast } from '../../contexts/ToastContext.jsx'
import { generateContractPDF } from '../../utils/contractExport'
import { formatCurrency, formatDate, formatDateTime } from '../../utils/formatters'
import { labelFor, PAYMENT_METHODS } from '../../utils/constants'
import { buildTemplateContext, fillTemplate, isClauseHeading, isDocumentTitle } from '../../utils/contractTemplate'

export default function ContractViewModal({ open, onClose, contract }) {
  const toast = useToast()
  const [busy, setBusy] = useState(null)

  const filledClauses = useMemo(() => {
    if (!contract) return []
    const { company, client, vehicle, rental, clauses = [] } = contract
    const context = buildTemplateContext(
      { company, client, vehicle, rental },
      { formatCurrency, formatDate, formatMileage: (m) => `${Number(m).toLocaleString('pt-BR')} km`, labelForPayment: (m) => labelFor(PAYMENT_METHODS, m) }
    )
    return clauses.map((raw) => fillTemplate(raw, context))
  }, [contract])

  if (!contract) return null
  const { company, client, contractNumber, issuedAt } = contract

  async function withPdf(action, label) {
    setBusy(label)
    try {
      const doc = await generateContractPDF(contract)
      action(doc)
    } catch (err) {
      console.error(err)
      toast.error('Não foi possível gerar o PDF do contrato')
    } finally {
      setBusy(null)
    }
  }

  const handleView = () => withPdf((doc) => window.open(doc.output('bloburl'), '_blank'), 'view')
  const handleDownload = () => withPdf((doc) => doc.save(`${contractNumber}.pdf`), 'download')
  const handlePrint = () =>
    withPdf((doc) => {
      doc.autoPrint()
      window.open(doc.output('bloburl'), '_blank')
    }, 'print')

  function handleEmail() {
    toast.info('Envio por e-mail em preparação', {
      description: `O contrato ${contractNumber} será enviado para ${client.email || 'o e-mail do cliente'} assim que a integração SMTP for configurada.`,
    })
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      size="lg"
      title={`Contrato ${contractNumber}`}
      subtitle={`Emitido em ${formatDateTime(issuedAt)}`}
    >
      <div className="mb-4 flex flex-wrap items-center gap-2.5">
        <Badge tone="emerald" dot>
          <FileCheck2 size={12} /> Emitido
        </Badge>
        <div className="ml-auto flex flex-wrap gap-2">
          <Button variant="secondary" size="sm" icon={busy === 'view' ? Loader2 : Eye} loading={busy === 'view'} onClick={handleView}>
            Visualizar
          </Button>
          <Button variant="secondary" size="sm" icon={busy === 'download' ? Loader2 : Download} loading={busy === 'download'} onClick={handleDownload}>
            Baixar PDF
          </Button>
          <Button variant="secondary" size="sm" icon={busy === 'print' ? Loader2 : Printer} loading={busy === 'print'} onClick={handlePrint}>
            Imprimir
          </Button>
          <Button variant="outline" size="sm" icon={Mail} onClick={handleEmail}>
            Enviar por e-mail
          </Button>
        </div>
      </div>

      {/* Paper-style preview — mirrors the PDF exactly, full legal text included */}
      <div className="max-h-[60vh] overflow-y-auto rounded-xl bg-mist-50 p-6 text-ink-950 shadow-inner">
        <div className="flex items-start justify-between border-b border-ink-950/10 pb-4">
          <div>
            <p className="text-[15px] font-bold">{company.name}</p>
            <p className="text-[10.5px] text-ink-600">{company.legalName} · CNPJ {company.cnpj}</p>
          </div>
          <div className="text-right">
            <p className="text-[12px] font-semibold">Contrato Nº {contractNumber}</p>
            <p className="text-[10.5px] text-ink-600">{formatDateTime(issuedAt)}</p>
          </div>
        </div>

        <div className="mt-4 leading-relaxed">
          {filledClauses.map((text, i) =>
            isDocumentTitle(text) ? (
              <p key={i} className="mb-4 text-center text-[13px] font-bold tracking-wide">{text}</p>
            ) : isClauseHeading(text) ? (
              <p key={i} className="mb-1.5 mt-4 text-[11px] font-bold text-ink-950">{text}</p>
            ) : (
              <p key={i} className="mb-1.5 text-justify text-[10.5px] text-ink-800">{text}</p>
            )
          )}
        </div>

        <div className="mt-6 grid grid-cols-2 gap-6 border-t border-ink-950/10 pt-6 text-center text-[10.5px]">
          <div>
            <div className="mx-auto mb-1 h-px w-full bg-ink-950/20" />
            {company.name} (Locadora)
          </div>
          <div>
            <div className="mx-auto mb-1 h-px w-full bg-ink-950/20" />
            {client.name} (Locatário)
          </div>
        </div>
      </div>
    </Modal>
  )
}
