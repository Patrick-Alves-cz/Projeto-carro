import { NavLink } from 'react-router-dom'
import clsx from 'clsx'
import {
  LayoutDashboard,
  Car,
  Users,
  FileSignature,
  Wallet,
  BarChart3,
  Settings,
  ChevronsLeft,
  ChevronsRight,
  ShieldCheck,
} from 'lucide-react'
import { useState } from 'react'
import { BrandMark } from '../shared/Logo.jsx'
import { useAuth } from '../../contexts/AuthContext.jsx'

const NAV_ITEMS = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/frota', label: 'Frota', icon: Car },
  { to: '/clientes', label: 'Clientes', icon: Users },
  { to: '/locacoes', label: 'Locações', icon: FileSignature },
  { to: '/financeiro', label: 'Financeiro', icon: Wallet },
  { to: '/relatorios', label: 'Relatórios', icon: BarChart3 },
  { to: '/configuracoes', label: 'Configurações', icon: Settings },
]

export default function Sidebar() {
  const [collapsed, setCollapsed] = useState(false)
  const { isAdmin } = useAuth()

  return (
    <aside
      className={clsx(
        'sticky top-0 flex h-screen shrink-0 flex-col border-r border-ink-700 bg-ink-900 transition-all duration-300 ease-premium',
        collapsed ? 'w-[76px]' : 'w-[248px]'
      )}
    >
      <div className={clsx('flex h-16 items-center gap-2.5 border-b border-ink-700 px-4', collapsed && 'justify-center px-0')}>
        <div className="flex h-9 w-9 shrink-0 items-center justify-center">
          <BrandMark size={28} />
        </div>
        {!collapsed && (
          <div className="min-w-0 leading-tight">
            <p className="truncate font-display text-[14px] font-extrabold tracking-tight text-mist-50">
              Loc<span className="text-brand-400">Fleet</span>
            </p>
            <p className="truncate font-display text-[8px] font-semibold tracking-[0.18em] text-mist-400">GESTÃO DE FROTAS</p>
          </div>
        )}
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) =>
              clsx(
                'group flex items-center gap-3 rounded-lg px-3 py-2.5 text-[13px] font-medium transition-all duration-200',
                collapsed && 'justify-center px-0',
                isActive
                  ? 'bg-brand-500/10 text-brand-400'
                  : 'text-mist-300 hover:bg-ink-800 hover:text-mist-50'
              )
            }
            title={collapsed ? item.label : undefined}
          >
            {({ isActive }) => (
              <>
                <item.icon size={17} strokeWidth={isActive ? 2.3 : 1.8} className="shrink-0" />
                {!collapsed && <span className="truncate">{item.label}</span>}
              </>
            )}
          </NavLink>
        ))}

        {isAdmin && (
          <NavLink
            to="/admin"
            className={({ isActive }) =>
              clsx(
                'group mt-2 flex items-center gap-3 rounded-lg border-t border-ink-700 px-3 pt-3.5 text-[13px] font-medium transition-all duration-200',
                collapsed && 'justify-center px-0',
                isActive ? 'text-brand-400' : 'text-mist-400 hover:text-mist-100'
              )
            }
            title={collapsed ? 'Painel admin' : undefined}
          >
            <ShieldCheck size={17} strokeWidth={1.8} className="shrink-0" />
            {!collapsed && <span className="truncate">Painel admin</span>}
          </NavLink>
        )}
      </nav>

      <button
        onClick={() => setCollapsed((v) => !v)}
        className={clsx(
          'flex h-11 items-center gap-2 border-t border-ink-700 px-4 text-[12px] font-medium text-mist-400 transition-colors hover:bg-ink-800 hover:text-mist-100',
          collapsed && 'justify-center px-0'
        )}
      >
        {collapsed ? <ChevronsRight size={15} /> : (
          <>
            <ChevronsLeft size={15} /> Recolher
          </>
        )}
      </button>
    </aside>
  )
}
