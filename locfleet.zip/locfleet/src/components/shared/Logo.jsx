export function BrandMark({ size = 32, className }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" className={className} aria-hidden="true">
      <path
        d="M 28 16 L 28 80 L 60 80"
        fill="none"
        stroke="#2BA6B5"
        strokeWidth="9"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M 28 54 Q 30 38 48 36 Q 58 35 62 30"
        fill="none"
        stroke="#2BA6B5"
        strokeWidth="9"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M 54 22 L 74 18 L 72 38"
        fill="none"
        stroke="#2BA6B5"
        strokeWidth="9"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default function Logo({ markSize = 34, showWordmark = true, wordmarkClassName, className }) {
  return (
    <div className={`flex items-center gap-2.5 ${className ?? ''}`}>
      <BrandMark size={markSize} />
      {showWordmark && (
        <div className={`leading-none ${wordmarkClassName ?? ''}`}>
          <p className="font-display text-[15px] font-extrabold tracking-tight text-mist-50">
            Loc<span className="text-brand-400">Fleet</span>
          </p>
          <p className="mt-0.5 font-display text-[8.5px] font-semibold tracking-[0.18em] text-mist-400">
            GESTÃO INTELIGENTE DE FROTAS
          </p>
        </div>
      )}
    </div>
  )
}
