import { ShieldAlert, FileWarning, IdCard, FileClock, Wrench, Landmark, BellOff } from 'lucide-react'
import clsx from 'clsx'
import Modal from '../ui/Modal.jsx'

const ICONS = {
  seguro: ShieldAlert,
  ipva: FileWarning,
  cnh: IdCard,
  contrato: FileClock,
  manutencao: Wrench,
  financiamento: Landmark,
}

const SEVERITY_STYLE = {
  critical: 'text-ruby-400 bg-ruby-500/10',
  high: 'text-amber-400 bg-amber-500/10',
  medium: 'text-azure-400 bg-azure-500/10',
}

const SEVERITY_LABEL = { critical: 'Urgente', high: 'Atenção', medium: 'Em dia' }

function severityText(alert) {
  if (alert.daysLeft === null) return 'Em andamento'
  if (alert.daysLeft < 0) return `Vencido há ${Math.abs(alert.daysLeft)}d`
  if (alert.daysLeft === 0) return 'Vence hoje'
  if (alert.daysLeft === 1) return 'Vence amanhã'
  return `Vence em ${alert.daysLeft}d`
}

export default function NotificationCenterModal({ open, onClose, alerts }) {
  return (
    <Modal open={open} onClose={onClose} size="md" title="Central de notificações" subtitle={`${alerts.length} item(ns) que precisam de atenção`}>
      {alerts.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-3 py-10 text-center">
          <div className="flex h-11 w-11 items-center justify-center rounded-full bg-ink-800 text-mist-400">
            <BellOff size={19} />
          </div>
          <p className="text-[13px] text-mist-400">Tudo em dia. Nenhuma pendência no momento.</p>
        </div>
      ) : (
        <ul className="flex flex-col divide-y divide-ink-700">
          {alerts.map((alert) => {
            const Icon = ICONS[alert.type] ?? FileWarning
            return (
              <li key={alert.id} className="flex items-center gap-3 py-3">
                <span className={clsx('flex h-9 w-9 shrink-0 items-center justify-center rounded-lg', SEVERITY_STYLE[alert.severity])}>
                  <Icon size={16} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13.5px] font-medium text-mist-100">{alert.title}</p>
                  <p className="truncate text-[12px] text-mist-400">{alert.subtitle}</p>
                </div>
                <div className="shrink-0 text-right">
                  <p className={clsx('text-[11.5px] font-semibold', SEVERITY_STYLE[alert.severity]?.split(' ')[0])}>
                    {severityText(alert)}
                  </p>
                  <p className="text-[10px] text-mist-500">{SEVERITY_LABEL[alert.severity]}</p>
                </div>
              </li>
            )
          })}
        </ul>
      )}
    </Modal>
  )
}
